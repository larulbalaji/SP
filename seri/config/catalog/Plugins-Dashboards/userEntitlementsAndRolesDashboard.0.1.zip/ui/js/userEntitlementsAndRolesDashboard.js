
console.log("Starting....");

//charts used in javascript
var usernameChart;
var usernameSelect;
var departmentPieChart;
var departmentSelect;
var jobTitlePieChart;
var jobTitleSelect;
var accountPieChart;
var accountSelect;
var attributeNamePieChart;
var attributeValueSelect;
var roleNamePieChart;
var roleNameSelect;
var roleTypePieChart;
var roleTypeSelect;
var assignmentPieChart;
var assignmentSelect;

//functions used to switch between detail and chart
function switchView(inputName){
	var sw = document.getElementById(inputName + "Switch");
	//reseting the existing filter on this dimension and rebuilding the chart
	eval(inputName + "PieChart").filterAll();
	eval(inputName + "Select").filterAll();
	dc.redrawAll();
	
	if(sw.innerHTML=="detail"){
		//switching to select
		document.getElementById(inputName + "Chart").style.display = "none";
		document.getElementById(inputName + "Detail").style.display = "inline";
		sw.innerHTML="chart";
	}else{
		//switching to chart
		document.getElementById(inputName + "Chart").style.display = "inline";
		document.getElementById(inputName + "Detail").style.display = "none";
		sw.innerHTML="detail";
	}
}


//Getting the raw data from the SCIM interface
d3.json("../scim/v2/Users?attributes=userName,urn:ietf:params:scim:schemas:sailpoint:1.0:User:entitlements,,urn:ietf:params:scim:schemas:sailpoint:1.0:User:roles,,urn:ietf:params:scim:schemas:sailpoint:1.0:User:department,,urn:ietf:params:scim:schemas:sailpoint:1.0:User:jobTitle", function(error, dataset){
	
	dataset.Resources.forEach(function(d) {
		if(d.userName==null) {
			d.userName = "Unknown";
		}
		if(d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].department==null) {
			d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].department = "Unknown";
		}
		if(d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].jobTitle==null) {
			d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].jobTitle = "Unknown";
		}
	});
	
	console.log("data parsed....");
	
	var ndx = crossfilter(dataset.Resources); 
	console.log("crossfilter object created....");
	//console.log("Data loaded: " + dataset);
	
	
	//============================================================================
	//  username
	//============================================================================
	var usernameDim  = ndx.dimension(function(d) {return d.userName;});
	var usernameGroup = usernameDim.group().reduceCount(function(d) {return d.id;});
	//Chart
	usernamePieChart  = dc.pieChart("#usernameChart"); 
	usernamePieChart
		.width(150).height(150)
		.dimension(usernameDim)
		.renderLabel(true)
		.group(usernameGroup)
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	usernameSelect = dc.selectMenu('#usernameSelect');
	usernameSelect
		.dimension(usernameDim)
		.group(usernameGroup)
		.multiple(true)
		.numberVisible(10)
		.controlsUseVisibility(true);
	
	//============================================================================
	//  department
	//============================================================================
	var departmentDim  = ndx.dimension(function(d) {return d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].department;});
	var departmentGroup = departmentDim.group().reduceCount(function(d) {return d.id;});
	//Chart
	departmentPieChart  = dc.pieChart("#departmentChart"); 
	departmentPieChart
		.width(150).height(150)
		.dimension(departmentDim)
		.renderLabel(true)
		.group(departmentGroup)
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	departmentSelect = dc.selectMenu('#departmentSelect');
	departmentSelect
		.dimension(departmentDim)
		.group(departmentGroup)
		.multiple(true)
		.numberVisible(10)
		.controlsUseVisibility(true);
		
		
	//============================================================================
	//  jobTitle
	//============================================================================
	var jobTitleDim  = ndx.dimension(function(d) {return d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].jobTitle;});
	var jobTitleGroup = jobTitleDim.group().reduceCount(function(d) {return d.id;});
	//Chart
	jobTitlePieChart  = dc.pieChart("#jobTitleChart"); 
	jobTitlePieChart
		.width(150).height(150)
		.dimension(jobTitleDim)
		.renderLabel(true)
		.group(jobTitleGroup)
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	jobTitleSelect = dc.selectMenu('#jobTitleSelect');
	jobTitleSelect
		.dimension(jobTitleDim)
		.group(jobTitleGroup)
		.multiple(true)
		.numberVisible(10)
		.controlsUseVisibility(true);
	
	//============================================================================
	//  application
	//============================================================================
	var applicationDim  = ndx.dimension(function(d) {return d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].entitlements;});
	var applicationGroup = applicationDim.groupAll().reduce(
		function reduceAdd(p, v) {
		  v["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].entitlements.forEach (function(val, idx) {
			 p[val.application] = (p[val.application] || 0) + 1; //increment counts
		  });
		  return p;
		},
		function reduceRemove(p, v) {
		  v["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].entitlements.forEach (function(val, idx) {
			 p[val.application] = (p[val.application] || 0) - 1; //decrement counts
		  });
		  return p;

		},
		function reduceInitial() {
		  return {};  
		}
	).value();
	applicationGroup.all = function() {
		  var newObject = [];
		  for (var key in this) {
			if (this.hasOwnProperty(key) && key != "all") {
			  newObject.push({
				key: key,
				value: this[key]
			  });
			}
		  }
		  return newObject;
		}
	//Chart
	applicationPieChart  = dc.pieChart("#applicationChart"); 
	applicationPieChart
		.width(150).height(150)
		.dimension(applicationDim)
		.renderLabel(true)
		.group(applicationGroup)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null){
					//console.log("#2" + applicationPieChart.filter());
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.application){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return false
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	applicationSelect = dc.selectMenu('#applicationSelect');
	applicationSelect
		.dimension(applicationDim)
		.group(applicationGroup)
		.multiple(true)
		.numberVisible(10)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null && filter.length >0){
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.application){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return true;
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.controlsUseVisibility(true);
	
	
	//============================================================================
	//  account
	//============================================================================
	var accountDim  = ndx.dimension(function(d) {return d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].entitlements;});
	var accountGroup = accountDim.groupAll().reduce(
		function reduceAdd(p, v) {
		  v["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].entitlements.forEach (function(val, idx) {
			 p[val.accountName] = (p[val.accountName] || 0) + 1; //increment counts
		  });
		  return p;
		},
		function reduceRemove(p, v) {
		  v["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].entitlements.forEach (function(val, idx) {
			 p[val.accountName] = (p[val.accountName] || 0) - 1; //decrement counts
		  });
		  return p;

		},
		function reduceInitial() {
		  return {};  
		}
	).value();
	accountGroup.all = function() {
		  var newObject = [];
		  for (var key in this) {
			if (this.hasOwnProperty(key) && key != "all") {
			  newObject.push({
				key: key,
				value: this[key]
			  });
			}
		  }
		  return newObject;
		}
	//Chart
	accountPieChart  = dc.pieChart("#accountChart"); 
	accountPieChart
		.width(150).height(150)
		.dimension(accountDim)
		.renderLabel(true)
		.group(accountGroup)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null){
					//console.log("#2" + accountPieChart.filter());
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.accountName){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return false
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	accountSelect = dc.selectMenu('#accountSelect');
	accountSelect
		.dimension(accountDim)
		.group(accountGroup)
		.multiple(true)
		.numberVisible(10)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null && filter.length >0){
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.accountName){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return true;
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.controlsUseVisibility(true);
		
		
	//============================================================================
	//  Role Name
	//============================================================================
	var roleNameDim  = ndx.dimension(function(d) {return d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].roles;});
	var roleNameGroup = roleNameDim.groupAll().reduce(
		function reduceAdd(p, v) {
		  v["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].roles.forEach (function(val, idx) {
			 p[val.display] = (p[val.display] || 0) + 1; //increment counts
		  });
		  return p;
		},
		function reduceRemove(p, v) {
		  v["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].roles.forEach (function(val, idx) {
			 p[val.display] = (p[val.display] || 0) - 1; //decrement counts
		  });
		  return p;

		},
		function reduceInitial() {
		  return {};  
		}
	).value();
	roleNameGroup.all = function() {
		  var newObject = [];
		  for (var key in this) {
			if (this.hasOwnProperty(key) && key != "all") {
			  newObject.push({
				key: key,
				value: this[key]
			  });
			}
		  }
		  return newObject;
		}
	//Chart
	roleNamePieChart  = dc.pieChart("#roleNameChart"); 
	roleNamePieChart
		.width(150).height(150)
		.dimension(roleNameDim)
		.renderLabel(true)
		.group(roleNameGroup)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null){
					//console.log("#2" + roleNamePieChart.filter());
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.display){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return false
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	roleNameSelect = dc.selectMenu('#roleNameSelect');
	roleNameSelect
		.dimension(roleNameDim)
		.group(roleNameGroup)
		.multiple(true)
		.numberVisible(10)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null && filter.length >0){
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.display){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return true;
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.controlsUseVisibility(true);
	
	//============================================================================
	//  Role Type
	//============================================================================
	var roleTypeDim  = ndx.dimension(function(d) {return d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].roles;});
	var roleTypeGroup = roleTypeDim.groupAll().reduce(
		function reduceAdd(p, v) {
		  v["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].roles.forEach (function(val, idx) {
			 p[val.type] = (p[val.type] || 0) + 1; //increment counts
		  });
		  return p;
		},
		function reduceRemove(p, v) {
		  v["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].roles.forEach (function(val, idx) {
			 p[val.type] = (p[val.type] || 0) - 1; //decrement counts
		  });
		  return p;

		},
		function reduceInitial() {
		  return {};  
		}
	).value();
	roleTypeGroup.all = function() {
		  var newObject = [];
		  for (var key in this) {
			if (this.hasOwnProperty(key) && key != "all") {
			  newObject.push({
				key: key,
				value: this[key]
			  });
			}
		  }
		  return newObject;
		}
	//Chart
	roleTypePieChart  = dc.pieChart("#roleTypeChart"); 
	roleTypePieChart
		.width(150).height(150)
		.dimension(roleTypeDim)
		.renderLabel(true)
		.group(roleTypeGroup)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null){
					//console.log("#2" + roleTypePieChart.filter());
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.type){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return false
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	roleTypeSelect = dc.selectMenu('#roleTypeSelect');
	roleTypeSelect
		.dimension(roleTypeDim)
		.group(roleTypeGroup)
		.multiple(true)
		.numberVisible(10)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null && filter.length >0){
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.type){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return true;
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.controlsUseVisibility(true);

	
	//============================================================================
	//  Assignment Type
	//============================================================================
	var assignmentDim  = ndx.dimension(function(d) {return d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].roles;});
	var assignmentGroup = assignmentDim.groupAll().reduce(
		function reduceAdd(p, v) {
		  v["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].roles.forEach (function(val, idx) {
			 p[val.acquired] = (p[val.acquired] || 0) + 1; //increment counts
		  });
		  return p;
		},
		function reduceRemove(p, v) {
		  v["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].roles.forEach (function(val, idx) {
			 p[val.acquired] = (p[val.acquired] || 0) - 1; //decrement counts
		  });
		  return p;

		},
		function reduceInitial() {
		  return {};  
		}
	).value();
	assignmentGroup.all = function() {
		  var newObject = [];
		  for (var key in this) {
			if (this.hasOwnProperty(key) && key != "all") {
			  newObject.push({
				key: key,
				value: this[key]
			  });
			}
		  }
		  return newObject;
		}
	//Chart
	assignmentPieChart  = dc.pieChart("#assignmentChart"); 
	assignmentPieChart
		.width(150).height(150)
		.dimension(assignmentDim)
		.renderLabel(true)
		.group(assignmentGroup)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null){
					//console.log("#2" + assignmentPieChart.filter());
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.acquired){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return false
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	assignmentSelect = dc.selectMenu('#assignmentSelect');
	assignmentSelect
		.dimension(assignmentDim)
		.group(assignmentGroup)
		.multiple(true)
		.numberVisible(10)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null && filter.length >0){
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.acquired){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return true;
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.controlsUseVisibility(true);

	
	//============================================================================
	//  Attribute Name
	//============================================================================
	var attributeNameDim  = ndx.dimension(function(d) {return d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].entitlements;});
	var attributeNameGroup = attributeNameDim.groupAll().reduce(
		function reduceAdd(p, v) {
		  v["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].entitlements.forEach (function(val, idx) {
			 p[val.value] = (p[val.value] || 0) + 1; //increment counts
		  });
		  return p;
		},
		function reduceRemove(p, v) {
		  v["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].entitlements.forEach (function(val, idx) {
			 p[val.value] = (p[val.value] || 0) - 1; //decrement counts
		  });
		  return p;

		},
		function reduceInitial() {
		  return {};  
		}
	).value();
	attributeNameGroup.all = function() {
		  var newObject = [];
		  for (var key in this) {
			if (this.hasOwnProperty(key) && key != "all") {
			  newObject.push({
				key: key,
				value: this[key]
			  });
			}
		  }
		  return newObject;
		}
	//Chart
	attributeNamePieChart  = dc.pieChart("#attributeNameChart"); 
	attributeNamePieChart
		.width(150).height(150)
		.dimension(attributeNameDim)
		.renderLabel(true)
		.group(attributeNameGroup)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null){
					//console.log("#2" + attributeNamePieChart.filter());
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.value){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return false
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	attributeNameSelect = dc.selectMenu('#attributeNameSelect');
	attributeNameSelect
		.dimension(attributeNameDim)
		.group(attributeNameGroup)
		.multiple(true)
		.numberVisible(10)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null && filter.length >0){
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.value){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return true;
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.controlsUseVisibility(true);


		
	//============================================================================
	//  Attribute Value
	//============================================================================
	var attributeValueDim  = ndx.dimension(function(d) {return d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].entitlements;});
	var attributeValueGroup = attributeValueDim.groupAll().reduce(
		function reduceAdd(p, v) {
		  v["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].entitlements.forEach (function(val, idx) {
			 p[val.display] = (p[val.display] || 0) + 1; //increment counts
		  });
		  return p;
		},
		function reduceRemove(p, v) {
		  v["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].entitlements.forEach (function(val, idx) {
			 p[val.display] = (p[val.display] || 0) - 1; //decrement counts
		  });
		  return p;

		},
		function reduceInitial() {
		  return {};  
		}
	).value();
	attributeValueGroup.all = function() {
		  var newObject = [];
		  for (var key in this) {
			if (this.hasOwnProperty(key) && key != "all") {
			  newObject.push({
				key: key,
				value: this[key]
			  });
			}
		  }
		  return newObject;
		}
	//Chart
	attributeValuePieChart  = dc.pieChart("#attributeValueChart"); 
	attributeValuePieChart
		.width(150).height(150)
		.dimension(attributeValueDim)
		.renderLabel(true)
		.group(attributeValueGroup)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null){
					//console.log("#2" + attributeValuePieChart.filter());
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.display){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return false
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	attributeValueSelect = dc.selectMenu('#attributeValueSelect');
	attributeValueSelect
		.dimension(attributeValueDim)
		.group(attributeValueGroup)
		.multiple(true)
		.numberVisible(10)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null && filter.length >0){
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.display){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return true;
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.controlsUseVisibility(true);
		
	document.getElementById("userEntitlementsAndRolesDashboardLoaded").innerHTML=ndx.size();

	//register handlers
	d3.selectAll('a#allReset').on('click', function () {
		dc.filterAll();
		dc.renderAll();
	});
	
	d3.selectAll('a#usernameReset').on('click', function () {
		usernamePieChart.filterAll();
		usernameSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#departmentReset').on('click', function () {
		departmentPieChart.filterAll();
		departmentSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#jobTitleReset').on('click', function () {
		jobTitlePieChart.filterAll();
		jobTitleSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#applicationReset').on('click', function () {
		applicationPieChart.filterAll();
		applicationSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#roleNameReset').on('click', function () {
		roleNamePieChart.filterAll();
		roleNameSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#roleTypeReset').on('click', function () {
		roleTypePieChart.filterAll();
		roleTypeSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#assignmentReset').on('click', function () {
		assignmentPieChart.filterAll();
		assignmentSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#accountReset').on('click', function () {
		accountPieChart.filterAll();
		accountSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#attributeNameReset').on('click', function () {
		attributeNamePieChart.filterAll();
		attributeNameSelect.filterAll();
		dc.redrawAll();
	});
		
	d3.selectAll('a#attributeValueReset').on('click', function () {
		attributeValuePieChart.filterAll();
		attributeValueSelect.filterAll();
		dc.redrawAll();
	});
	
	dc.renderAll(); 
	document.getElementById("loadingDiv").style.display = "none";
	document.getElementById("containerDiv").style.display = "block";

	
});
console.log("Ending");