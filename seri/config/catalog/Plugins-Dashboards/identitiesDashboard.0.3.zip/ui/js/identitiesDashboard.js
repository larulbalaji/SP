
console.log("Starting....");

//charts used in javascript
var statusPieChart;
var statusSelect;
var employeeTypePieChart;
var employeeTypeSelect;
var regionPieChart;
var regionSelect;
var locationPieChart;
var locationSelect;
var departmentPieChart;
var departmentSelect;
var jobTitlePieChart;
var jobTitleSelect;
var managerPieChart;
var managerSelect;
var accountPieChart;
var accountSelect;

//functions used to switch between detail and chart
function switchView(inputName){
	var sw = document.getElementById(inputName + "Switch");
	//reseting the existing filter on this dimension and rebuilding the chart
	eval(inputName + "PieChart").filterAll();
	eval(inputName + "Select").filterAll();
	dc.redrawAll();
	
	if(sw.innerHTML=="detail"){
		//switching to select
		document.getElementById(inputName + "Chart").style.display = "none";
		document.getElementById(inputName + "Detail").style.display = "inline";
		sw.innerHTML="chart";
	}else{
		//switching to chart
		document.getElementById(inputName + "Chart").style.display = "inline";
		document.getElementById(inputName + "Detail").style.display = "none";
		sw.innerHTML="detail";
	}
}

//Getting the raw data from the SCIM interface
d3.json("../scim/v2/Users?attributes=active,userName,displayName,urn:ietf:params:scim:schemas:sailpoint:1.0:User:employeeType,urn:ietf:params:scim:schemas:sailpoint:1.0:User:region,urn:ietf:params:scim:schemas:sailpoint:1.0:User:location,urn:ietf:params:scim:schemas:sailpoint:1.0:User:department,urn:ietf:params:scim:schemas:sailpoint:1.0:User:jobTitle,urn:ietf:params:scim:schemas:extension:enterprise:2.0:User:manager,urn:ietf:params:scim:schemas:sailpoint:1.0:User:riskScore,urn:ietf:params:scim:schemas:sailpoint:1.0:User:accounts,meta", function(error, dataset){
	
	//var parserDate = d3.time.format("%Y-%m-%dT%H:%M:%S").parse;
	var parserDate = d3.time.format.utc("%Y-%m-%d");
	
	dataset.Resources.forEach(function(d) {
		if(d.active==null){
			d.active = "Unknown";
		}else if(d.active==true){
			d.active="Active";
		}else{
			d.active="Inactive";
		}
		if(d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].employeeType==null) {
			d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].employeeType = "Unknown";
		}
		if(d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].region==null) {
			d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].region = "Unknown";
		}
		if(d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].location==null) {
			d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].location = "Unknown";
		}
		if(d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].department==null) {
			d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].department = "Unknown";
		}
		if(d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].jobTitle==null) {
			d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].jobTitle = "Unknown";
		}
		if(d["urn:ietf:params:scim:schemas:extension:enterprise:2.0:User"].manager.displayName==null) {
			d["urn:ietf:params:scim:schemas:extension:enterprise:2.0:User"].manager.displayName = "Unknown";
		}
		if(d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].riskScore==null) {
			d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].riskScore = 0;
		}
		
		d.account = 0;
		d.account = 0;
		if(d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].accounts!=null){
			d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].accounts.forEach(function(acc){
				d.account++;
				//console.log(acc.displayName);
			});
		}
		if(d.meta.created!=null){
			//console.log(d.meta.created);
			d.meta.created = d.meta.created.substring(0,10);
			//console.log(d.meta.created);
			d.meta.created = parserDate.parse(d.meta.created);
			//console.log(d.meta.created);
		}
	});
	
	console.log("data parsed....");
	
	var ndx = crossfilter(dataset.Resources); 
	console.log("crossfilter object created....");
	//console.log("Data loaded: " + dataset);
		
	//status
	var statusDim  = ndx.dimension(function(d) {return d.active;});
	var statusGroup = statusDim.group().reduceCount(function(d) {return d.id;});
	//Chart
	statusPieChart  = dc.pieChart("#statusChart"); 
	statusPieChart
		.width(150).height(150)
		.dimension(statusDim)
		.renderLabel(true)
		.group(statusGroup)
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	statusSelect = dc.selectMenu('#statusSelect');
	statusSelect
		.dimension(statusDim)
		.group(statusGroup)
		.multiple(true)
		.numberVisible(10)
		.controlsUseVisibility(true);
		
	//EmployeeType
	var employeeTypeDim  = ndx.dimension(function(d) {return d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].employeeType;});
	var employeeTypeGroup = employeeTypeDim.group().reduceCount(function(d) {return d.id;});
	//Chart
	employeeTypePieChart  = dc.pieChart("#employeeTypeChart"); 
	employeeTypePieChart
		.width(150).height(150)
		.dimension(employeeTypeDim)
		.renderLabel(true)
		.group(employeeTypeGroup)
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	
	//Select
	employeeTypeSelect = dc.selectMenu('#employeeTypeSelect');
	employeeTypeSelect
		.dimension(employeeTypeDim)
		.group(employeeTypeGroup)
		.multiple(true)
		.numberVisible(10)
		.controlsUseVisibility(true);
		
	//Region
	var regionDim  = ndx.dimension(function(d) {return d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].region;});
	var regionGroup = regionDim.group().reduceCount(function(d) {return d.id;});
	//Chart
	regionPieChart  = dc.pieChart("#regionChart"); 
	regionPieChart
		.width(150).height(150)
		.dimension(regionDim)
		.renderLabel(true)
		.group(regionGroup)
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	
	//Select
	regionSelect = dc.selectMenu('#regionSelect');
	regionSelect
		.dimension(regionDim)
		.group(regionGroup)
		.multiple(true)
		.numberVisible(10)
		.controlsUseVisibility(true);
	
	//Location
	var locationDim  = ndx.dimension(function(d) {return d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].location;});
	var locationGroup = locationDim.group().reduceCount(function(d) {return d.id;});
	//Chart
	locationPieChart  = dc.pieChart("#locationChart"); 
	locationPieChart
		.width(150).height(150)
		.dimension(locationDim)
		.renderLabel(true)
		.group(locationGroup)
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	
	//Select
	locationSelect = dc.selectMenu('#locationSelect');
	locationSelect
		.dimension(locationDim)
		.group(locationGroup)
		.multiple(true)
		.numberVisible(10)
		.controlsUseVisibility(true);
	
	//Department
	var departmentDim  = ndx.dimension(function(d) {return d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].department;});
	var departmentGroup = departmentDim.group().reduceCount(function(d) {return d.id;});
	//Chart
	departmentPieChart  = dc.pieChart("#departmentChart"); 
	departmentPieChart
		.width(150).height(150)
		.dimension(departmentDim)
		.renderLabel(true)
		.group(departmentGroup)
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 }); 
	//Select
	departmentSelect = dc.selectMenu('#departmentSelect');
	departmentSelect
		.dimension(departmentDim)
		.group(departmentGroup)
		.multiple(true)
		.numberVisible(10)
		.controlsUseVisibility(true);
		
	//JobTitle
	var jobTitleDim  = ndx.dimension(function(d) {return d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].jobTitle;});
	var jobTitleGroup = jobTitleDim.group().reduceCount(function(d) {return d.id;});
	//Chart
	jobTitlePieChart  = dc.pieChart("#jobTitleChart"); 
	jobTitlePieChart
		.width(150).height(150)
		.dimension(jobTitleDim)
		.renderLabel(true)
		.group(jobTitleGroup)
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 }); 
	//Select
	jobTitleSelect = dc.selectMenu('#jobTitleSelect');
	jobTitleSelect
		.dimension(jobTitleDim)
		.group(jobTitleGroup)
		.multiple(true)
		.numberVisible(10)
		.controlsUseVisibility(true);
		
		
	//Manager
	var managerDim  = ndx.dimension(function(d) {return d["urn:ietf:params:scim:schemas:extension:enterprise:2.0:User"].manager.displayName;});
	var managerGroup = managerDim.group().reduceCount(function(d) {return d.id;});
	//Chart
	managerPieChart  = dc.pieChart("#managerChart"); 
	managerPieChart
		.width(150).height(150)
		.dimension(managerDim)
		.renderLabel(true)
		.group(managerGroup)
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 }); 
	//Select
	managerSelect = dc.selectMenu('#managerSelect');
	managerSelect
		.dimension(managerDim)
		.group(managerGroup)
		.multiple(true)
		.numberVisible(10)
		.controlsUseVisibility(true);
		
	//Account
	var accountDim  = ndx.dimension(function(d) {return d.account;});
	var accountGroup = accountDim.group().reduceCount(function(d) {return d.id;});
	//Chart
	accountPieChart  = dc.pieChart("#accountChart"); 
	accountPieChart
		.width(150).height(150)
		.dimension(accountDim)
		.renderLabel(true)
		.group(accountGroup)
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 }); 
	//Select
	accountSelect = dc.selectMenu('#accountSelect');
	accountSelect
		.dimension(accountDim)
		.group(accountGroup)
		.multiple(true)
		.numberVisible(10)
		.controlsUseVisibility(true);
	
	//Risk
	var riskDim = ndx.dimension(function(d) {return d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].riskScore;});
	var riskGroup = riskDim.group().reduceCount(function(d) {return d.id;});
	
	var riskLineChart = dc.lineChart("#riskChart");
	riskLineChart
          .width(950)
          .height(250)
          .x(d3.scale.linear().domain([0,1000]))
		  .elasticX(true)
		  .elasticY(true)
          .brushOn(true)
          .xAxisLabel("Identity Risk Score")
          .yAxisLabel("Number of Identities")
          .dimension(riskDim)
          .group(riskGroup)
		  .controlsUseVisibility(true);
	
	//Creation Date
	var creationDim = ndx.dimension(function(d) {return d.meta.created;});
	var creationGroup = creationDim.group().reduceCount(function(d) {return d.id;});
	
	var creationLineChart = dc.lineChart("#creationChart");
	creationLineChart
          .width(950)
          .height(250)
          .x(d3.time.scale())
		  .xUnits(d3.time.days)
		  .elasticX(true)
		  .elasticY(true)
          .brushOn(true)
          .xAxisLabel("Creation Date")
          .yAxisLabel("Number of Identities")
          .dimension(creationDim)
          .group(creationGroup)
		  .controlsUseVisibility(true);
	
	//Identities List
	var identitiesList   = dc.dataTable("#identitiesList");
	identitiesList
		.dimension(departmentDim)
		.group(function(d) {return d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].department;})
		// dynamic columns creation using an array of closures
		.columns([
			function(d) {return d.userName;},
			function(d) {return "<a href=\"../identities/identities.jsf#/identities/" + d.id + "/attributes\" target=\"_blank\">" + d.displayName + "</>";},
			function(d) {return "<a href=\"../identities/identities.jsf#/identities/" + d["urn:ietf:params:scim:schemas:extension:enterprise:2.0:User"].manager.value + "/attributes\" target=\"_blank\">" + d["urn:ietf:params:scim:schemas:extension:enterprise:2.0:User"].manager.displayName + "</>";},
			function(d) {return d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].jobTitle;},
			function(d) {return d["urn:ietf:params:scim:schemas:sailpoint:1.0:User"].riskScore;}
		])
		.on('renderlet', function (table) {
            table.selectAll('.dc-table-group').classed('info', true);
        });
		
	document.getElementById("identitiesLoaded").innerHTML=ndx.size();
	
	//register handlers
	d3.selectAll('a#allReset').on('click', function () {
		dc.filterAll();
		dc.renderAll();
	});
	
	d3.selectAll('a#statusReset').on('click', function () {
		statusPieChart.filterAll();
		statusSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#employeeTypeReset').on('click', function () {
		employeeTypePieChart.filterAll();
		employeeTypeSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#regionReset').on('click', function () {
		regionPieChart.filterAll();
		regionSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#locationReset').on('click', function () {
		locationPieChart.filterAll();
		locationSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#departmentReset').on('click', function () {
		departmentPieChart.filterAll();
		departmentSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#jobTitleReset').on('click', function () {
		jobTitlePieChart.filterAll();
		jobTitleSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#managerReset').on('click', function () {
		managerPieChart.filterAll();
		managerSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#accountReset').on('click', function () {
		accountPieChart.filterAll();
		accountSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#riskReset').on('click', function () {
		riskLineChart.filterAll();
		dc.redrawAll();
	});

	d3.selectAll('a#creationReset').on('click', function () {
		creationLineChart.filterAll();
		dc.redrawAll();
	});
	
	dc.renderAll(); 
	document.getElementById("loadingDiv").style.display = "none";
	document.getElementById("containerDiv").style.display = "block";
	
});
console.log("Ending");