
console.log("Starting....");

//charts used in javascript
var applicationPieChart;
var applicationSelect;
var statusPieChart;
var statusSelect;
var lockedPieChart;
var lockedSelect;
var servicePieChart;
var serviceSelect;
var privilegePieChart;
var privilegeSelect;

//functions used to switch between detail and chart
function switchView(inputName){
	var sw = document.getElementById(inputName + "Switch");
	//reseting the existing filter on this dimension and rebuilding the chart
	eval(inputName + "PieChart").filterAll();
	eval(inputName + "Select").filterAll();
	dc.redrawAll();
	
	if(sw.innerHTML=="detail"){
		//switching to select
		document.getElementById(inputName + "Chart").style.display = "none";
		document.getElementById(inputName + "Detail").style.display = "inline";
		sw.innerHTML="chart";
	}else{
		//switching to chart
		document.getElementById(inputName + "Chart").style.display = "inline";
		document.getElementById(inputName + "Detail").style.display = "none";
		sw.innerHTML="detail";
	}
}

//Getting the raw data from the SCIM interface
d3.json("../scim/v2/Accounts", function(error, dataset){
	
	//var parserDate = d3.time.format("%Y-%m-%dT%H:%M:%S").parse;
	var parserDate = d3.time.format.utc("%Y-%m-%d");
	
	dataset.Resources.forEach(function(d) {
		if(d.application.displayName==null) {
			d.application.displayName = "Unknown";
		}
		if(d.active==null){
			d.active = "Unknown";
		}else if(d.active==true){
			d.active="Active";
		}else{
			d.active="Inactive";
		}
		if(d.locked==null){
			d.locked = "Unknown";
		}
		if(d.service==null){
			d.service = "Unknown";
		}
		if(d.privileged==null){
			d.privileged = "Unknown";
		}
		
		if(d.meta.created!=null){
			//console.log(d.meta.created);
			d.meta.created = d.meta.created.substring(0,10);
			//console.log(d.meta.created);
			d.meta.created = parserDate.parse(d.meta.created);
			//console.log(d.meta.created);
		}
	});
	
	console.log("data parsed....");
	
	var ndx = crossfilter(dataset.Resources); 
	console.log("crossfilter object created....");
	//console.log("Data loaded: " + dataset);
	
	//application
	var applicationDim  = ndx.dimension(function(d) {return d.application.displayName;});
	var applicationGroup = applicationDim.group().reduceCount(function(d) {return d.id;});
	//Chart
	applicationPieChart  = dc.pieChart("#applicationChart"); 
	applicationPieChart
		.width(150).height(150)
		.dimension(applicationDim)
		.renderLabel(true)
		.group(applicationGroup)
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	applicationSelect = dc.selectMenu('#applicationSelect');
	applicationSelect
		.dimension(applicationDim)
		.group(applicationGroup)
		.multiple(true)
		.numberVisible(10)
		.controlsUseVisibility(true);
	
	
	//status
	var statusDim  = ndx.dimension(function(d) {return d.active;});
	var statusGroup = statusDim.group().reduceCount(function(d) {return d.id;});
	//Chart
	statusPieChart  = dc.pieChart("#statusChart"); 
	statusPieChart
		.width(150).height(150)
		.dimension(statusDim)
		.renderLabel(true)
		.group(statusGroup)
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	statusSelect = dc.selectMenu('#statusSelect');
	statusSelect
		.dimension(statusDim)
		.group(statusGroup)
		.multiple(true)
		.numberVisible(10)
		.controlsUseVisibility(true);
		
	//Locked
	var lockedDim  = ndx.dimension(function(d) {return d.locked;});
	var lockedGroup = lockedDim.group().reduceCount(function(d) {return d.id;});
	//Chart
	lockedPieChart  = dc.pieChart("#lockedChart"); 
	lockedPieChart
		.width(150).height(150)
		.dimension(lockedDim)
		.renderLabel(true)
		.group(lockedGroup)
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	lockedSelect = dc.selectMenu('#lockedSelect');
	lockedSelect
		.dimension(lockedDim)
		.group(lockedGroup)
		.multiple(true)
		.numberVisible(10)
		.controlsUseVisibility(true);
		
	//Service
	var serviceDim  = ndx.dimension(function(d) {return d.service;});
	var serviceGroup = serviceDim.group().reduceCount(function(d) {return d.id;});
	//Chart
	servicePieChart  = dc.pieChart("#serviceChart"); 
	servicePieChart
		.width(150).height(150)
		.dimension(serviceDim)
		.renderLabel(true)
		.group(serviceGroup)
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	serviceSelect = dc.selectMenu('#serviceSelect');
	serviceSelect
		.dimension(serviceDim)
		.group(serviceGroup)
		.multiple(true)
		.numberVisible(10)
		.controlsUseVisibility(true);
	
	//Privileged
	var privilegedDim  = ndx.dimension(function(d) {return d.privileged;});
	var privilegedGroup = privilegedDim.group().reduceCount(function(d) {return d.id;});
	//Chart
	privilegedPieChart  = dc.pieChart("#privilegedChart"); 
	privilegedPieChart
		.width(150).height(150)
		.dimension(privilegedDim)
		.renderLabel(true)
		.group(privilegedGroup)
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	privilegedSelect = dc.selectMenu('#privilegedSelect');
	privilegedSelect
		.dimension(privilegedDim)
		.group(privilegedGroup)
		.multiple(true)
		.numberVisible(10)
		.controlsUseVisibility(true);
	
	//Creation Date
	var creationDim = ndx.dimension(function(d) {return d.meta.created;});
	var creationGroup = creationDim.group().reduceCount(function(d) {return d.id;});
	
	var creationLineChart = dc.lineChart("#creationChart");
	creationLineChart
          .width(950)
          .height(250)
          .x(d3.time.scale())
		  .xUnits(d3.time.days)
		  .elasticX(true)
		  .elasticY(true)
          .brushOn(true)
          .xAxisLabel("Creation Date")
          .yAxisLabel("Number of Accounts")
          .dimension(creationDim)
          .group(creationGroup)
		  .controlsUseVisibility(true);
	
	//Accounts List
	var accountDim = ndx.dimension(function(d) {return d.identity.displayName;});
	var accountsList   = dc.dataTable("#accountsList");
	accountsList
		.dimension(accountDim)
		.group(function(d) {return d.identity.displayName;})
		// dynamic columns creation using an array of closures
		.columns([
			function(d) {return d.application.displayName;},
			function(d) {return "<a href=\"../identities/identities.jsf#/identities/" + d.identity.value + "/accounts\" target=\"_blank\">" + d.displayName + "</>";}
		])
		.on('renderlet', function (table) {
            table.selectAll('.dc-table-group').classed('info', true);
        });
		
	document.getElementById("accountsLoaded").innerHTML=ndx.size();
	
	//register handlers
	d3.selectAll('a#allReset').on('click', function () {
		dc.filterAll();
		dc.renderAll();
	});
	
	d3.selectAll('a#applicationReset').on('click', function () {
		applicationPieChart.filterAll();
		applicationSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#statusReset').on('click', function () {
		statusPieChart.filterAll();
		statusSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#lockedReset').on('click', function () {
		lockedPieChart.filterAll();
		lockedSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#serviceReset').on('click', function () {
		servicePieChart.filterAll();
		serviceSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#privilegedReset').on('click', function () {
		privilegedPieChart.filterAll();
		privilegedSelect.filterAll();
		dc.redrawAll();
	});

	d3.selectAll('a#creationReset').on('click', function () {
		creationLineChart.filterAll();
		dc.redrawAll();
	});
	
	dc.renderAll(); 
	document.getElementById("loadingDiv").style.display = "none";
	document.getElementById("containerDiv").style.display = "block";

	
});
console.log("Ending");