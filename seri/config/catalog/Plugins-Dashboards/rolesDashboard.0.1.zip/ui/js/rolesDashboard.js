
console.log("Starting....");

//charts used in javascript
var typePieChart;
var typeSelect;
var statusPieChart;
var statusSelect;
var ownerPieChart;
var ownerSelect;
var inheritancePieChart;
var inheritanceSelect;
var requirementsPieChart;
var requirementsSelect;
var permitsPieChart;
var permitsSelect;

//functions used to switch between detail and chart
function switchView(inputName){
	var sw = document.getElementById(inputName + "Switch");
	//reseting the existing filter on this dimension and rebuilding the chart
	eval(inputName + "PieChart").filterAll();
	eval(inputName + "Select").filterAll();
	dc.redrawAll();
	
	if(sw.innerHTML=="detail"){
		//switching to select
		document.getElementById(inputName + "Chart").style.display = "none";
		document.getElementById(inputName + "Detail").style.display = "inline";
		sw.innerHTML="chart";
	}else{
		//switching to chart
		document.getElementById(inputName + "Chart").style.display = "inline";
		document.getElementById(inputName + "Detail").style.display = "none";
		sw.innerHTML="detail";
	}
}


//Getting the raw data from the SCIM interface
d3.json("../scim/v2/Roles", function(error, dataset){
	
	//var parserDate = d3.time.format("%Y-%m-%dT%H:%M:%S").parse;
	var parserDate = d3.time.format.utc("%Y-%m-%d");
	
	dataset.Resources.forEach(function(d) {
		if(d.type.displayName==null) {
			d.type.displayName = "Unknown";
		}
		if(d.active==null){
			d.active = "Unknown";
		}else if(d.active==true){
			d.active="Active";
		}else{
			d.active="Inactive";
		}
		if(d.owner.displayName==null) {
			d.owner.displayName = "Unknown";
		}/*
		if(d.inheritance.displayName==null) {
			d.inheritance.displayName = "Unknown";
		}
		if(d.requirements.displayName==null) {
			d.requirements.displayName = "Unknown";
		}
		if(d.permits.displayName==null) {
			d.permits.displayName = "Unknown";
		}*/
		if(d.meta.created!=null){
			//console.log(d.meta.created);
			d.meta.created = d.meta.created.substring(0,10);
			//console.log(d.meta.created);
			d.meta.created = parserDate.parse(d.meta.created);
			//console.log(d.meta.created);
		}
	});
	
	console.log("data parsed....");
	
	var ndx = crossfilter(dataset.Resources); 
	console.log("crossfilter object created....");
	//console.log("Data loaded: " + dataset);
	
	
	//============================================================================
	//  type
	//============================================================================
	var typeDim  = ndx.dimension(function(d) {return d.type.displayName;});
	var typeGroup = typeDim.group().reduceCount(function(d) {return d.id;});
	//Chart
	typePieChart  = dc.pieChart("#typeChart"); 
	typePieChart
		.width(150).height(150)
		.dimension(typeDim)
		.renderLabel(true)
		.group(typeGroup)
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	typeSelect = dc.selectMenu('#typeSelect');
	typeSelect
		.dimension(typeDim)
		.group(typeGroup)
		.multiple(true)
		.numberVisible(10)
		.controlsUseVisibility(true);
	
	//============================================================================
	//  status
	//============================================================================
	var statusDim  = ndx.dimension(function(d) {return d.active;});
	var statusGroup = statusDim.group().reduceCount(function(d) {return d.id;});
	//Chart
	statusPieChart  = dc.pieChart("#statusChart"); 
	statusPieChart
		.width(150).height(150)
		.dimension(statusDim)
		.renderLabel(true)
		.group(statusGroup)
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	statusSelect = dc.selectMenu('#statusSelect');
	statusSelect
		.dimension(statusDim)
		.group(statusGroup)
		.multiple(true)
		.numberVisible(10)
		.controlsUseVisibility(true);
		
		
	//============================================================================
	//  owner
	//============================================================================
	var ownerDim  = ndx.dimension(function(d) {return d.owner.displayName;});
	var ownerGroup = ownerDim.group().reduceCount(function(d) {return d.id;});
	//Chart
	ownerPieChart  = dc.pieChart("#ownerChart"); 
	ownerPieChart
		.width(200).height(200)
		.dimension(ownerDim)
		.renderLabel(true)
		.group(ownerGroup)
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	ownerSelect = dc.selectMenu('#ownerSelect');
	ownerSelect
		.dimension(ownerDim)
		.group(ownerGroup)
		.multiple(true)
		.numberVisible(10)
		.controlsUseVisibility(true);
	
	//============================================================================
	//  inheritance
	//============================================================================
	var inheritanceDim  = ndx.dimension(function(d) {return d.inheritance;});
	var inheritanceGroup = inheritanceDim.groupAll().reduce(
		function reduceAdd(p, v) {
		  v.inheritance.forEach (function(val, idx) {
			 p[val.displayName] = (p[val.displayName] || 0) + 1; //increment counts
		  });
		  return p;
		},
		function reduceRemove(p, v) {
		  v.inheritance.forEach (function(val, idx) {
			 p[val.displayName] = (p[val.displayName] || 0) - 1; //decrement counts
		  });
		  return p;

		},
		function reduceInitial() {
		  return {};  
		}
	).value();
	inheritanceGroup.all = function() {
		  var newObject = [];
		  for (var key in this) {
			if (this.hasOwnProperty(key) && key != "all") {
			  newObject.push({
				key: key,
				value: this[key]
			  });
			}
		  }
		  return newObject;
		}
	//Chart
	inheritancePieChart  = dc.pieChart("#inheritanceChart"); 
	inheritancePieChart
		.width(200).height(200)
		.dimension(inheritanceDim)
		.renderLabel(true)
		.group(inheritanceGroup)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null){
					//console.log("#2" + inheritancePieChart.filter());
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.displayName){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return false
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	inheritanceSelect = dc.selectMenu('#inheritanceSelect');
	inheritanceSelect
		.dimension(inheritanceDim)
		.group(inheritanceGroup)
		.multiple(true)
		.numberVisible(10)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null && filter.length >0){
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.displayName){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return true;
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.controlsUseVisibility(true);

	//============================================================================
	//  requirements
	//============================================================================
	var requirementsDim  = ndx.dimension(function(d) {return d.requirements;});
	var requirementsGroup = requirementsDim.groupAll().reduce(
		function reduceAdd(p, v) {
		  v.requirements.forEach (function(val, idx) {
			 p[val.displayName] = (p[val.displayName] || 0) + 1; //increment counts
		  });
		  return p;
		},
		function reduceRemove(p, v) {
		  v.requirements.forEach (function(val, idx) {
			 p[val.displayName] = (p[val.displayName] || 0) - 1; //decrement counts
		  });
		  return p;

		},
		function reduceInitial() {
		  return {};  
		}
	).value();
	requirementsGroup.all = function() {
		  var newObject = [];
		  for (var key in this) {
			if (this.hasOwnProperty(key) && key != "all") {
			  newObject.push({
				key: key,
				value: this[key]
			  });
			}
		  }
		  return newObject;
		}
	//Chart
	requirementsPieChart  = dc.pieChart("#requirementsChart"); 
	requirementsPieChart
		.width(200).height(200)
		.dimension(requirementsDim)
		.renderLabel(true)
		.group(requirementsGroup)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null){
					//console.log("#2" + inheritancePieChart.filter());
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.displayName){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return false
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	requirementsSelect = dc.selectMenu('#requirementsSelect');
	requirementsSelect
		.dimension(requirementsDim)
		.group(requirementsGroup)
		.multiple(true)
		.numberVisible(10)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null && filter.length >0){
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.displayName){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return true;
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.controlsUseVisibility(true);
	
	
	
	//============================================================================
	//  permits
	//============================================================================
	var permitsDim  = ndx.dimension(function(d) {return d.permits;});
	var permitsGroup = permitsDim.groupAll().reduce(
		function reduceAdd(p, v) {
		  v.permits.forEach (function(val, idx) {
			 p[val.displayName] = (p[val.displayName] || 0) + 1; //increment counts
		  });
		  return p;
		},
		function reduceRemove(p, v) {
		  v.permits.forEach (function(val, idx) {
			 p[val.displayName] = (p[val.displayName] || 0) - 1; //decrement counts
		  });
		  return p;

		},
		function reduceInitial() {
		  return {};  
		}
	).value();
	permitsGroup.all = function() {
		  var newObject = [];
		  for (var key in this) {
			if (this.hasOwnProperty(key) && key != "all") {
			  newObject.push({
				key: key,
				value: this[key]
			  });
			}
		  }
		  return newObject;
		}
	//Chart
	permitsPieChart  = dc.pieChart("#permitsChart"); 
	permitsPieChart
		.width(200).height(200)
		.dimension(permitsDim)
		.renderLabel(true)
		.group(permitsGroup)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null){
					//console.log("#2" + inheritancePieChart.filter());
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.displayName){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return false
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.on('pretransition', function(chart) {
			chart.selectAll('text.pie-slice').text(function(d) {
				var prct = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100);
				var label = d.data.key + ' ' + dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2*Math.PI) * 100) + '%';
				if(prct>15)
					return label;
				else
					return "";
			});
		 });
	//Select
	permitsSelect = dc.selectMenu('#permitsSelect');
	permitsSelect
		.dimension(permitsDim)
		.group(permitsGroup)
		.multiple(true)
		.numberVisible(10)
		.filterHandler(function(dimension, filter){
			dimension.filter(function(d) {
				if(filter != null && filter.length >0){
					returnValue=false;
					d.forEach(function(e){
						filter.forEach(function(f){
							if(f == e.displayName){
								returnValue = true;
							}
						});
					});
					return returnValue;
				}else{
					return true;
				}
			}); // perform filtering
			return filter; // return the actual filter value
		   })
		.controlsUseVisibility(true);
	
	//============================================================================
	//  Creation Date
	//============================================================================
	var creationDim = ndx.dimension(function(d) {return d.meta.created;});
	var creationGroup = creationDim.group().reduceCount(function(d) {return d.id;});
	
	var creationLineChart = dc.lineChart("#creationChart");
	creationLineChart
          .width(650)
          .height(180)
          .x(d3.time.scale())
		  .xUnits(d3.time.days)
		  .elasticX(true)
		  .elasticY(true)
          .brushOn(true)
          .xAxisLabel("Creation Date")
          .yAxisLabel("Number of Accounts")
          .dimension(creationDim)
          .group(creationGroup)
		  .controlsUseVisibility(true);
		
	//============================================================================
	//  Role List
	//============================================================================
	
	var rolesDim = ndx.dimension(function(d) {return d.type.displayName;});
	var rolesList   = dc.dataTable("#rolesList");
	rolesList
		.dimension(rolesDim)
		.group(function(d) {return d.type.displayName;})
		// dynamic columns creation using an array of closures
		.columns([
			function(d) {return d.displayableName;},
			function(d) {return "<a href=\"../identities/identities.jsf#/identities/" + d.owner.value + "/access\" target=\"_blank\">" + d.owner.displayName + "</>";},
			function(d) {	var values="";
							if(d.inheritance!=null){
								d.inheritance.forEach(function (d){ 
									if(d!=null){
										if(d.displayName!=null){
											values += d.displayName + " <BR/>";
										}
									}
								});
								return values;
							}else{
								return "";
							}
						},
			function(d) {	var values="";
							if(d.requirements!=null){
								d.requirements.forEach(function (d){ 
									if(d!=null){
										if(d.displayName!=null){
											values += d.displayName + " <BR/>";
										}
									}
								});
								return values;
							}else{
								return "";
							}
						},
			function(d) {	var values="";
							if(d.permits!=null){
								d.permits.forEach(function (d){ 
									if(d!=null){
										if(d.displayName!=null){
											values += d.displayName + " <BR/>";
										}
									}
								});
								return values;
							}else{
								return "";
							}
						}
		])
		.on('renderlet', function (table) {
            table.selectAll('.dc-table-group').classed('info', true);
        });
		
	document.getElementById("rolesLoaded").innerHTML=ndx.size();
	
	//register handlers
	d3.selectAll('a#allReset').on('click', function () {
		dc.filterAll();
		dc.renderAll();
	});
	
	d3.selectAll('a#typeReset').on('click', function () {
		typePieChart.filterAll();
		typeSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#statusReset').on('click', function () {
		statusPieChart.filterAll();
		statusSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#ownerReset').on('click', function () {
		ownerPieChart.filterAll();
		ownerSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#inheritanceReset').on('click', function () {
		inheritancePieChart.filterAll();
		inheritanceSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#requirementsReset').on('click', function () {
		requirementsPieChart.filterAll();
		requirementsSelect.filterAll();
		dc.redrawAll();
	});
	
	d3.selectAll('a#permitsReset').on('click', function () {
		permitsPieChart.filterAll();
		permitsSelect.filterAll();
		dc.redrawAll();
	});

	d3.selectAll('a#creationReset').on('click', function () {
		creationLineChart.filterAll();
		dc.redrawAll();
	});
	
	dc.renderAll(); 
	document.getElementById("loadingDiv").style.display = "none";
	document.getElementById("containerDiv").style.display = "block";

	
});
console.log("Ending");