function loadLogs(){
	items = [];
	logsHtml=[];
	var logPath = document.getElementById("filePath").value;
	jQuery.get(logPath,  function (data) {
		myData = data.split('\n');
		items.push(getSubItems("file","log",myData,""));
		
		index=1;
		items.forEach(function(d){
			logsHtml.push(getHtml(d,index,undefined));
			index++;
		});
		
		logsHtml;
		document.getElementById("logs").innerHTML=logsHtml.join("\n");
	 });
}
function getHtml(item,level,levels){
	var html=[];
	if(levels==undefined){
		levels = "<span class='" + item.type + "'>" + level + "</span>";
	}
	//open first div
	html.push("<div class='" + item.type + "' id=" + level + ">" + levels + "<span class='" + item.type + "'>");
	if(item.subItems.length > 0){
		html.push("&nbsp;<a href=\"javascript:switchDisplay('spanSub"  + level + "');\"><span id='switchspanSub" + level + "'>+<span></a>");
	}else{
		html.push("-");
	}

	html.push(item.name + "</span>");
	
	if(item.logs.length>0){
		//open spanLog
		html.push(" - [" + item.type + "]&nbsp;" + item.time + "&nbsp;<a href=\"javascript:switchDisplay('spanLog"  + level + "');\">logs</a>&nbsp;<span class='logs' style='display:none' id='spanLog"  + level + "'><xmp>");
		item.logs.forEach(function(e){
			html.push(e);
		});
		//close spanLog
		html.push("</xmp></span>");
	}
	
	//open spanSub
	html.push("<span class='sub" + item.type + "' style='display:none' id='spanSub"  + level + "'>");
	var index2=1;
	item.subItems.forEach(function(e){
		html.push(getHtml(e,level + " - " + index2,levels+" - <span class='" + e.type + "'>" + index2 + "</span>"));
		index2++;
	});
	
	//close spanSub
	html.push("</span>");
	if(item.type=="workflow"){
		html.push(levels + "<span class='" + item.type + "'> - Ending " + item.name + "</span>");
	}	
	html.push("</div>");
	
	return html.join("\n");
}

function getSubItems(type,name,logs,level,time){
	if(level==undefined){
		level = 1;
	}
	//console.log(level + " Starting getSubItem... type #" + type + "# name #" + name + "#");
	//console.log(logs);
	var item={};
	item.name=name;
	item.type=type;
	item.time=time;
	item.logs=[];
	item.subItems=[];
	var subItem=false;
	var subType,subName,subTime;
	var subLogs=[];
	var duplicates=0;
	var index=0;
	logs.forEach(function (log){
		index++;
		if(log.indexOf("Starting " + subType + " " + subName)!=-1){
			//this is a subitem with the same name as the top level item
			duplicates++;
			//console.log(level + " " + index + " Found a duplicate for this item #" + duplicates + "#"); 
		}
		if(log.indexOf("Ending " + subType + " " + subName)!=-1){
			if(duplicates==0){
				//console.log(level + " " + index + "  Reached the end of the subItem. " + subName +  " Calling getSubItem..." + log);
				//this is the item end
				item.subItems.push(getSubItems(subType,subName,subLogs,level+1,subTime));
				subType=undefined;
				subName=undefined;
				subTime=undefined;
				subLogs=[];
				subItem=false;
			}else{
				duplicates--;
				//console.log(level + " " + index+ "  Removed a duplicate for this item #" + duplicates + "#");
				subLogs.push(log);
			}
		} else if(subItem){
			//console.log(level + " " + index+ "  Just a subItem log...");
			subLogs.push(log);
		}else if(log.indexOf("Starting ")!=-1){
			subType=log.substring(log.indexOf("Starting ")+9);
			//removing the part after the type
			subType=subType.substring(0,subType.indexOf(" "));
			subItem=true;
			subName=log.substring(log.indexOf("Starting " + subType)+10 +subType.length);
			subTime=log.substring(0,23);
			//console.log(level + " " + index + " SubItem type #" + subType + "# SubItem name #" + subName + "# " + logs.length + " " + log );
		}else{
			//just a log
			//console.log(level + " " + index + "  Just a log");
			item.logs.push(log);
		}
		
	});
	return item;
}
	
function switchDisplay(id){
	var span = document.getElementById(id);
	if(span.style.display=="none"){
		span.style.display="inline";
	}else{
		span.style.display="none";
	}
}

function hideAll(type,hide){
	var spans = document.getElementsByTagName('span');
	for(var i=0;i<spans.length;i++){
		var span = spans[i];
		if(type=="both" || (type=="logs" && span.id.startsWith("spanLog")) || (type=="items" && span.id.startsWith("spanSub")) ){
			if(hide){
				span.style.display="none";
			}else{
				span.style.display="inline";
			}
		}
	};
}
