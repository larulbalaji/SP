jQuery(document).ready(function(){
	var uvaUrl = SailPoint.CONTEXT_PATH + '/plugins/pluginPage.jsf?pn=logTail';
	var menu=jQuery("#debugMenu").next();
	menu.append('<li role="presentation">'
				+'<a href="' + uvaUrl + '" role="menuitem" class="menuitem" tabindex="0">'
                +'Log Tail'
				+'</a>'
				+'</li>');

});