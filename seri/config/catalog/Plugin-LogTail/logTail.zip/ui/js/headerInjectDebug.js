jQuery(document).ready(function(){
	var uvaUrl = SailPoint.CONTEXT_PATH + '/debug/debug.jsf';
	var menu=jQuery("#preferenceMenu").next();
	menu.append('<li role="presentation">'
				+'<a href="' + uvaUrl + '" role="menuitem" class="menuitem" tabindex="0">'
                +'Debug'
				+'</a>'
				+'</li>');

});