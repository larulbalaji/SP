﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpLibrary
{
    public class DataLoader
    {
        public static string GetData(string sText = "This is the default value")
        {
            return "This is a static string that comes from GetData. It optionally has a parameter, which is this:" + sText;
        }
    }
}
