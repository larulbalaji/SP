﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace SharpLibrary
{
    public class FileLoader : IDisposable
    {
        public string LoadFile(string sFileName = "C:\\temp\\Dave.txt")
        {
            try
            {
                using (StreamReader sr = new StreamReader(sFileName))
                {
                    return sr.ReadToEnd();
                }
            }
            catch (Exception exc)
            {
                return exc.Message;
            }
        }

        public void Dispose()
        {
            //Nothing to do here, we don't need to dispose anything.
        }
    }
}
