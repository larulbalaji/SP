﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace libDaveStuff
{
    /// <summary>
    /// DataLoader has a single static method that returns a string.
    /// </summary>
    public class DataLoader
    {
        public static string GetData()
        {
            return "This is some data loaded from the class library";
        }
    }

    /// <summary>
    /// DataReader has a couple of methods that return data of dubious usefulness
    /// </summary>
    public class DataReader
    {
        /// <summary>
        /// GetData returns a string and appends the string passed into it at the end.
        /// </summary>
        /// <param name="sInputString"></param>
        /// <returns></returns>
        public string GetData(string sInputString = "C:\\temp\\this.txt")
        {
            return "This method reads data from the target. It also optionally takes a parameter, which is this:" + sInputString;
        }

        /// <summary>
        /// GetDataFromFile does what the name suggests - it loads text from a file.
        /// </summary>
        /// <param name="sFilePath">Defaults to C:\temp\dave.txt</param>
        /// <returns></returns>
        public string GetDataFromFile(string sFilePath = "C:\\temp\\dave.txt")
        {
            string sData = "No Data Loaded";
            try
            {
                using (StreamReader sr = new StreamReader(sFilePath))
                {
                    sData = sr.ReadToEnd();
                }
            }
            catch(Exception exc)
            {
                sData = exc.Message;
            }

            return sData;

        }
    }
}
