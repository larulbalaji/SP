﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SharpLibrary;

namespace SampleForm
{
    public partial class Form1 : Form
    {
        int iClickTracker = -1;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnShowHide_Click(object sender, EventArgs e)
        {
            txtDisplay.Visible = !txtDisplay.Visible;
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            string sDisplayText = "No text selected";
            iClickTracker = (iClickTracker + 1) % 5;
            switch (iClickTracker)
            {
                case 0:
                    sDisplayText = "Load this data";
                    break;
                case 1:
                    sDisplayText = SharpLibrary.DataLoader.GetData();
                    break;
                case 2:
                    sDisplayText = SharpLibrary.DataLoader.GetData("I added a parameter to the GetData static method.");
                    break;
                case 3:
                    FileLoader fileLoad = new FileLoader();
                    sDisplayText = fileLoad.LoadFile();
                    break;
                case 4:
                    using (FileLoader dataFile = new FileLoader())
                    {
                        sDisplayText = dataFile.LoadFile("C:\\temp\\passwords.txt");
                    }
                    break;
                default:
                    sDisplayText = "Default";
                    break;
            }
            txtDisplay.Text = sDisplayText;
        }
    }
}
