﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace ScratchMain
{
    public partial class Form1 : Form
    {
        int iDataLoadCounter = 0;

        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// This method loads data into the visual form
        /// </summary>
        private void LoadData()
        {
            string sText = "No Data Loaded";
            libDaveStuff.DataReader drTemp = new libDaveStuff.DataReader();
            iDataLoadCounter = (iDataLoadCounter + 1) % 5;
            switch(iDataLoadCounter)
            {
                case 0:
                    sText = libDaveStuff.DataLoader.GetData();
                    break;
                case 1:
                    sText = drTemp.GetData();
                    break;
                case 2:
                    sText = drTemp.GetData("F:\\This\\Is\\A\\New\\Path.txt");
                    break;
                case 3:
                    sText = drTemp.GetDataFromFile();
                    break;
                case 4:
                    sText = drTemp.GetDataFromFile("C:\\Temp\\passwords.txt");
                    break;
                default:
                    break;
            }
            txtDisplay.Text = sText;
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnShowHide_Click(object sender, EventArgs e)
        {
            txtDisplay.Visible = !txtDisplay.Visible;
        }
    }
}
