(function() {
   'use strict';

function SIQKPIInjectorCtrl(SearchData, PageState, PagingData, $q, $timeout, configService, siqKPIService, navigationService, ListResultDTO, ListResultCache) {
    //'ngInject';
    //console.log("CTRL");
    var me = this, 
    // The number of items to load into the cache at once.
    CACHE_CHUNK_SIZE = 40, 
    // The search term used the list time the data was loaded.
    lastSearchTerm, 
    // A cache of all of the results that have been loaded.
    cache = new ListResultCache(), 
    // Flag indicating that we are fetching results to go to the previous page.
    // See description in previousPage().
    fetchForPreviousPage = false, 
    resource = undefined,
    ownerscore = undefined,
    owner = undefined,
    // A timeout promise that will refresh the list results after going to the previous page.
    // See description in previousPage().
    previousPageRefreshPromise;
    ////////////////////////////////////////////////////////////////////////
    //
    // CONSTRUCTOR
    //
    ////////////////////////////////////////////////////////////////////////
    SIQKPIInjectorCtrl._super.call(this, SearchData, $q, $timeout, configService, new PageState(new PagingData(5)));
    ////////////////////////////////////////////////////////////////////////
    //
    // AbstractListCtrl methods
    //
    ////////////////////////////////////////////////////////////////////////
    /**
     * Return the requested items from the cache wrapped in a promise.
     *
     * @param {Number} startIdx  The start index to retrieve.
     * @param (Number) numItems  The number of items to retrieve.
     *
     * @return {Promise<ListResultDTO>} A promise that resolves with a ListResultDTO with the
     *     requested items, or null if the cache does not contain these items.
     */
    function getFromCache(startIdx, numItems) {
        var cached = cache.get(startIdx, numItems);
        return (cached) ? $q.when(cached) : null;
    }
    /**
     * Reset the cache and current page information if the search term differs from the previous
     * search.
     *
     * @param {String} newSearchTerm  The current search term.
     */
    function resetIfSearchChanged(newSearchTerm) {
        if (lastSearchTerm !== newSearchTerm) {
            // Clear the cache
            cache.reset();
            // Save the new search term to remember it for our next fetch.
            lastSearchTerm = newSearchTerm;
            // Reset the displayed page number back to 0.
            me.displayedPageNumber = 0;
        }
    }
    /**
     * Search for the direct reports.
     *
     * @param {String} searchTerm  Ignored.
     * @param {Object} filterValues  Ignored.
     * @param {Number} startIdx  The zero-based start index.
     * @param {Number} itemsPerPage  The number of items to display per page.
     * @param {SortOrder} sortOrder The SortOrder holding sorts. May be null or undefined.
     *
     * @return {Promise<ListResult>} A promise that will resolve to a ListResult
     *     with the requested items.
     */
    this.doSearch = function (searchTerm, filterValues, startIdx, itemsPerPage, sortOrder) {
        // First, reset stuff if the search term is changing.
        resetIfSearchChanged(searchTerm);
        // If we are going to the previous page we need to keep extra results in the list so
        // that they are displayed while the animation is sliding up.  Four pages worth is enough
        // of a buffer to quickly click the previous button a number of times and not see any
        // blank rows scrolling by.
        if (fetchForPreviousPage) {
            itemsPerPage = itemsPerPage * 4;
        }
        // We're starting at index 0 because of the animation that we are using for the list.
        // The list will always include all items up to the end of the last page.  We show the
        // appropriate page by sliding the list up and down.  Since we are hiding the overflow,
        // only the desired window of information is shown.
        var listStart = 0, listEnd = startIdx + itemsPerPage, results;
        // First try to load the results from the cache.
        results = getFromCache(listStart, listEnd);
        // If not found in the cache, hit the server.
        if (!results) {
            results = loadIntoCache(searchTerm, startIdx).then(function () {
                // Now that its in the cache, get the requested stuff back from the cache.
                return getFromCache(listStart, listEnd);
            });
        }
        
        getOwnerScoreData();

        // Wrap the result in an HTTP Promise looking thing.
        return results.then(function (listResult) {
            return {
                data: listResult
            };
        });
    };
    /**
     * Load the next chunk of data into the cache, starting at the given index.
     *
     * @param {String} searchTerm  The search typed into the filter input box.
     * @param {Number} startIdx  The start index to load into the cache.
     *
     * @return {Promise<ListResultDTO>} A promise that resolves with the data that was loaded.
     */
    function loadIntoCache(searchTerm, startIdx) {
    	//console.log("Calling Service");

       
        return siqKPIService.getSIQKPIS(searchTerm, startIdx, CACHE_CHUNK_SIZE).then(function (kpis) {
            // Add the loaded data to the cache.
            cache.add(kpis, startIdx, CACHE_CHUNK_SIZE);
            return kpis;
        });

    
    }
    
    function getOwnerScoreData() {
    

        
        return siqKPIService.getOwnerScore().then(function (ownerdata) {
        
        	me.owner = ownerdata.owner;
        	me.ownerscore = ownerdata.ownerscore;
        	me.resource = ownerdata.resource;
       
            // Add the loaded data to the cache.
            return ownerdata;
        });
    }
    /**
     * We don't support filters - just return an empty list.
     */
    this.doLoadFilters = function () {
        // No-op - just return an empty list.
        return $q.when([]);
    };
    /**
     * Helper method to handle focusing and animations when changing page
     * @param {Function} changePageFunc Super method to call to actually change the page
     */
    function changePage(changePageFunc) {
        return changePageFunc().then(function () {
            // Current page is 1-based, so subtract 1 to get a zero-based index.
            me.displayedPageNumber = me.pageState.pagingData.currentPage - 1;
            // This must be in a timeout or else the watch in the focus snatcher doesn't get the correct values.
            $timeout(function () {
                me.focusOnList = true;
            });
        }).then(function () {
            // After changing the page, preload more data into the cache if we need to.
            preloadCache();
        });
    }
    /**
     * If we are near the end of our cached data, load some more.
     */
    function preloadCache() {
        var loadedSize = me.pageState.pagingData.getStart() + me.pageState.pagingData.itemsPerPage;
        // If we're within a couple pages of the end of the cache, go ahead and load more data.
        if (loadedSize >= cache.size - 10) {
            loadIntoCache(me.pageState.searchData.searchTerm, cache.size);
        }
      
    }
    /**
     * Extend nextPage() to focus on the list after the data is loaded, set data required by
     * animations, and preload data into the cache if needed.
     */
    this.nextPage = function () {
        // Don't need to do a previous page refetch since we're moving the list again.
        cancelPreviousPageRefetch();
        // Do the paging.
        changePage(SensitiveDataUserWidgetDirectiveCtrl._super.prototype.nextPage.bind(me));
    };
    /**
     * If there is a pending request to refetch a previous page, cancel it.
     */
    function cancelPreviousPageRefetch() {
        if (previousPageRefreshPromise) {
            $timeout.cancel(previousPageRefreshPromise);
            previousPageRefreshPromise = null;
        }
    }
    /**
     * Extend previousPage() to focus on the list after the data is loaded, set data required by
     * animations, and preload data into the cache if needed.
     */
    this.previousPage = function () {
        // Set this to true so we keep some extra rows in the list while the animation is happening.
        fetchForPreviousPage = true;
        changePage(SIQKPIDirectiveCtrl._super.prototype.previousPage.bind(me))["finally"](function () {
            // Cancel the existing request to refetch if there is one.
            cancelPreviousPageRefetch();
            // Wait a couple of seconds and then trim the results to the actual desired size once
            // the transition is complete.
            previousPageRefreshPromise = $timeout(function () {
                me.fetchItems();
            }, 2000);
        });
        // Set this back to false for the next request.
        fetchForPreviousPage = false;
    };
    ////////////////////////////////////////////////////////////////////////
    //
    // Direct report methods
    //
    ////////////////////////////////////////////////////////////////////////
    /**
     * Go to the View Identity page for the given directReport.
     *
     * @param {DirectReport} directReport The direct report.
     */
    this.viewIdentity = function (sensUser) {
    
        navigationService.go({
            outcome: 'viewIdentity#/identities/' + sensUser.id + '/attributes'
        });
    };
    /**
     * Go to the Manage Access page for the given directReport.
     *
     * @param {DirectReport} directReport The direct report.
     */
    this.requestAccess = function (entUser) {
        navigationService.go({
            outcome: 'requestAccess#/accessRequest/manageAccess/add?identityName=' + entUser.name
        });
    };
    /**
     * Go to the Manage Passwords page for the given directReport.
     *
     * @param {DirectReport} directReport The direct report.
     */
    this.managePasswords = function (entUser) {
        navigationService.go({
            outcome: 'managePasswords#/identities/' + entUser.id + '/passwords'
        });
    };
    /**
     * Go to the Manage Accounts page for the given directReport.
     *
     * @param {DirectReport} directReport The direct report.
     */
    this.manageAccounts = function (entUser) {
        navigationService.go({
            outcome: 'manageAccounts#/identities/' + entUser.id + '/accounts'
        });
    };
    ////////////////////////////////////////////////////////////////////////
    //
    // INITIALIZATION
    //
    ////////////////////////////////////////////////////////////////////////
    /**
     * @property {Array<Object>}  Config objects with information about the buttons to render.
     */
    this.buttonConfigs = [{
            action: 'requestAccess',
            onClick: this.requestAccess,
            iconCls: 'fa-key',
            tooltip: 'quicklink_request_access',
            srText: 'direct_report_request_access_sr'
        }, {
            action: 'managePasswords',
            onClick: this.managePasswords,
            iconCls: 'fa-unlock-alt',
            tooltip: 'quicklink_manage_passwords',
            srText: 'direct_report_manage_passwords_sr'
        }, {
            action: 'manageAccounts',
            onClick: this.manageAccounts,
            iconCls: 'fa-folder',
            tooltip: 'quicklink_manage_accounts',
            srText: 'direct_report_manage_accounts_sr'
        }];
    /**
     * @property {Boolean}  A flag that gets set to true after paging to draw the focus back to
     *     the top of the list.
     */
    this.focusOnList = false;
    /**
     * @property {Number}  The zero-based number of the page that is being displayed.
     */
    this.displayedPageNumber = 0;
    // We need a truthy columnConfigs value for AbstractListCtrl to work even though we aren't
    // using them.
    this.columnConfigs = [];
    // Initialize when the controller is constructed.
    this.initialize();
}
SIQKPIInjectorCtrl.$inject = ['SearchData', 'PageState', 'PagingData', '$q', '$timeout', 'configService', 'siqKPIService', 'navigationService', 'ListResultDTO', 'ListResultCache'];

SailPoint.extend(SIQKPIInjectorCtrl, AbstractListCtrl);


    var me2 = this;
    var widgetFunction = function() {
        angular.module('sailpoint.home.desktop.app')
        .factory('SIQKPI', function() {
           function SIQKPI() {
	   
	       }
	
        function SIQKPI(data) {
        if (!data) {
            throw 'data is required';
        }
        if (!data.statName) {
            throw 'name is required';
        }
        if (!data.statScore) {
            throw 'statScore is required';
        }
        if (!data.statValue) {
            throw 'statValue is required';
        }
        
        if (!data.statColor){
        	throw 'statColor is required';
        }

        this.statValue = data.statValue;
     
        this.statName = data.statName;

        this.statScore = data.statScore;
        
        this.statColor = data.statColor;
        
    }



    return SIQKPI;
		       })
        .service('siqKPIService', ['SP_CONTEXT_PATH', 'ListResultDTO', 'SIQKPI', '$http',
                 function(SP_CONTEXT_PATH, ListResultDTO, SIQKPI, $http) {
            this.getSIQKPIS = function(searchTerm, start, limit) {
                var params = {
                    start: start,
                    limit: limit
                };

                // Only send the search term if it was specified.
                if (searchTerm) {
                    params.query = searchTerm;
                }
	          return $http.get(SP_CONTEXT_PATH + '/plugin/rest/siqstats/stats', {
            params: params
        }).then(function(response) {
            // Convert the objects in the response into DirectReports.
            var transformed = angular.copy(response.data);
            //console.log(transformed);
            transformed.objects = transformed.objects.map(function(siqkpi) {
                return new SIQKPI(siqkpi);
            });

            return new ListResultDTO(transformed);
        });
    };
		this.getOwnerScore = function() {
        //console.log("GetOwnerScore Function");      
        return $http.get(SP_CONTEXT_PATH + '/plugin/rest/siqstats/ownerdata').then(function(response) {
        	
            var ownerdata = angular.copy(response.data);
            //console.log(transformed);
            
            return ownerdata;
        });
		};
			

        }])
    	.controller('SIQKPIInjectorCtrl', SIQKPIInjectorCtrl)
        .directive('spSIQStatsWidget', function() {
	     //console.log("Directive");
	    return {
	        restrict: 'E',
	        scope: {
	            widget: '=spWidget'
	        },
	        controller: 'SIQKPIInjectorCtrl',
	        controllerAs: 'ctrl',
	        bindToController: true,
	    
	         template:
	            '<div class="direct-reports-widget">' +
	            '  <div class="panel-body" sp-loading-mask="ctrl.items">' +
	            '    <div tabindex="50" class="list-group reports-list"' +
	            '         sp-focus-snatcher="ctrl.focusOnList"' +
	            '         sp-focus-snatcher-element="#directReportRow{{ ctrl.getPageState().pagingData.getStart() }}"' +
	            '         sp-focus-snatcher-wait="1250"' +
	            /*
	             * To page the results with a sliding effect we are using CSS transitions.  The top property
	             * has a transition.  When the page is changed we scroll the page up 250 more pixels.  The
	             * overflow is hidden so the part that gets scrolled up is not seen and the next 5 entries
	             * come into the window.
	             */
	            '         ng-style="{ \'top\': -250 * ctrl.displayedPageNumber + \'px\' }">' +
	            '      <div class="list-group-item text-center empty-widget"' +
	            '           ng-if="ctrl.items.length === 0">' +
	            '        <p class="h4 text-muted">{{ \'ui_widget_no_data\' | spTranslate }}</p>' +
	            '      </div>' +
	            '      <div class="list-group-item" ng-repeat="kpi in ctrl.items track by $index">' +
	            '        <div class="row" tabindex="-1" id="directReportRow{{ $index }}">' +
	            '          <div class="col-sm-8">' +
	            '              <span class="text-ellipsis"><b>{{ ::kpi.statValue }} {{ ::kpi.statName }}</b></span>' +
	            '          </div>' +
	            '          <div class="col-sm-4 text-right">' +
	      
	            '             <span ng-switch on="kpi.statColor">' +
	            '                <span ng-switch-when="Green" class="text-ellipsis" style="color:Green">{{ ::kpi.statScore }} score</span>' +
	            '                <span ng-switch-when="Orange" class="text-ellipsis" style="color:Orange">{{ ::kpi.statScore }} score</span>' +
	            '                <span ng-switch-when="Red" class="text-ellipsis" style="color:Red">{{ ::kpi.statScore }} score</span>' +
	            '             </span>' + 
	         
	            '          </div>' +
	            '        </div>' +
	            '      </div>' +
	            '    </div>' +
	            '  </div>' +
	            '  <div class="panel-footer">' +
	            '    <div class="row">' +
	            '      <div class="col-xs-9">' +
	            '        <p class="m-t-xs m-b-xs">' +
	            '          <span class="text-ellipsis" id="siqOwnerData">{{ ctrl.resource }}   <b>Owner:</b>{{ ctrl.owner }}</span>' + 
	            '        </p>' +
	            '      </div>' +
	            '      <div id="directReportsPageInfo" class="col-xs-3 text-right">' +
	            '        <p class="inline m-t-xs m-b-xs m-r-sm">' +
	            '          (Score:{{ ctrl.ownerscore }})' +
	            '        </p>' +
	            '      </div>' +
	            '    </div>' +
	            '  </div>' +
	            '</div>'
	    };
});
    };
PluginHelper.addWidgetFunction(widgetFunction);	
})();

