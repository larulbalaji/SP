
/*

Other available values to build paths, etc. that are obtained from the server and set in the PluginFramework JS object

PluginFramework.PluginBaseEndpointName = '#{pluginFramework.basePluginEndpointName}';
PluginFramework.PluginEndpointRoot = '#{pluginFramework.basePluginEndpointName}/#{pluginFramework.basePluginEndpointName}';
PluginFramework.PluginFolderName = '#{pluginFramework.pluginFolderName}';
PluginFramework.CurrentPluginUniqueName = '#{pluginFramework.uniqueName}';
PluginFramework.CsrfToken = Ext.util.Cookies.get('CSRF-TOKEN');

 */


var identDashUrl = SailPoint.CONTEXT_PATH + '/pluginPage.jsf?pn=identityandaccountdashboard';
jQuery(document).ready(function(){
	jQuery("a[href='/identityiq/manage/riskScores/appRiskScores.jsf']").parent()
		.after(
			  ' <li role="presentation" aria-hidden="true" class="divider"></li>'+
                '<li role="presentation">'+
                '<a href="'+identDashUrl+'" role="menuitem" class="menuitem" tabindex="0">'+
                'Identity Dashboard'+
                '</a>'+
                '</li>'
			
/*
			
				'<li class="dropdown">' +
				'		<a href="' + identDashUrl + '" tabindex="0" role="menuitem" data-snippet-debug="off">' +
				'			<i role="presenation" class="fa fa-exclamation fa-lg example"></i>' +
				'		</a>' +
				'</li>'
*/
		);
});
