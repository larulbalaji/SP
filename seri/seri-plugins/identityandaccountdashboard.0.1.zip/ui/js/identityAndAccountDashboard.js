
'use strict';

/* jshint globalstrict: true */
/* global dc,d3,crossfilter,colorbrewer */

// ### Create Chart Objects

// Create chart objects associated with the container elements identified by the css selector.
// Note: It is often a good idea to have these objects accessible at the global scope so that they can be modified or
// filtered by other page controls.

var quarterChart = dc.pieChart('#quarter-chart');
var dayOfWeekChart = dc.rowChart('#day-of-week-chart');
var applicationChart = dc.barChart('#application-chart');
var eventChart = dc.lineChart('#monthly-move-chart');
var rangeChart = dc.barChart('#monthly-volume-chart');
var scatterPlot = dc.scatterPlot('#yearly-bubble-chart');
var filteredCount = dc.dataCount('.dc-data-count');
var eventTable = dc.dataTable('.dc-data-table');

// ### Anchor Div for Charts
/*
// A div anchor that can be identified by id
    <div id='your-chart'></div>
// Title or anything you want to add above the chart
    <div id='chart'><span>Days by Gain or Loss</span></div>
// ##### .turnOnControls()

// If a link with css class `reset` is present then the chart
// will automatically hide/show it based on whether there is a filter
// set on the chart (e.g. slice selection for pie chart and brush
// selection for bar chart). Enable this with `chart.turnOnControls(true)`

// dc.js >=2.1 uses `visibility: hidden` to hide/show controls without
// disrupting the layout. To return the old `display: none` behavior,
// set `chart.controlsUseVisibility(false)` and use that style instead.
    <div id='chart'>
       <a class='reset'
          href='javascript:myChart.filterAll();dc.redrawAll();'
          style='visibility: hidden;'>reset</a>
    </div>
// dc.js will also automatically inject the current filter value into
// any html element with its css class set to `filter`
    <div id='chart'>
        <span class='reset' style='visibility: hidden;'>
          Current filter: <span class='filter'></span>
        </span>
    </div>
*/

//### Load your data

//Data can be loaded through regular means with your
//favorite javascript library
//
//```javascript
//d3.csv('data.csv', function(data) {...});
//d3.json('data.json', function(data) {...});
//jQuery.getJson('data.json', function(data){...});
//```

//add a number of days to an existing date
Date.prototype.addDays = function(days)
{
    var dat = new Date(this.valueOf());
    dat.setDate(dat.getDate() + days);
    return dat;
}

//ar tempdate=new Date("2015/01/01");
//console.log(tempdate);
//console.log(tempdate.addDays(1));
//exit();


var all_dates=[];
var all_weeks=[];
var all_months=[];


//sort group so that zeros are in proper slot
function sort_group(group, order) {
    return {
        all: function() {
            var g = group.all(), map = {};

            g.forEach(function(kv) {
                map[kv.key] = kv.value;
            });
            return order.map(function(k) {
                return {key: k, value: map[k]};
            });
        }
    };
};







//adding in zeros to the data
function ensure_group_bins(source_group, bins) { // (source_group, bins...}
    var bins = Array.prototype.slice.call(arguments, 1);
    return {
        all:function () {
            var result = source_group.all().slice(0), // copy original results (we mustn't modify them)
                found = {};
            result.forEach(function(d) {
                found[d.key] = true;
            });
            //console.log("found********");
            //console.log(found);
           // console.log("bins********");
           // console.log(bins);
            var loop=0;
            bins[0].forEach(function(d) {
	         //   console.log(loop+": inside foreach ");
	          //  console.log("d: "+d);

                if(!found[d])
                {
	                //console.log("not found!");
	                var item = {key: d, value: 0};
	                result.splice(loop, 0, item);
//                    result.push({key: d, value: 0});
                    }
                   //else
                    //{console.log("found:");}
                    	            loop=loop+1;
            });
            //            console.log("result********");
           // console.log(result);
            return result;
        }
    };
};




//sort 



  // Like d3.time.format, but faster.
  function parseDate(d) {
//	  console.log("in parse date:"+d);
	  
	  return new Date(Math.round(d/1000)*1000);
  }
  
  
    var nestByDate = d3.nest()
      .key(function(d) { return d3.time.day(d.date); });

                    var IDENT_DASHBOARD_URL = PluginHelper.getPluginRestUrl('identityandaccountdashboard/getIdentityData');
                    //console.log(IDENT_DASHBOARD_URL);
      
   jQuery.ajax({

	                method: "GET",
	                beforeSend: function (request) {

	                    request.setRequestHeader("X-XSRF-TOKEN", PluginHelper.getCsrfToken());
	                },
	                url: IDENT_DASHBOARD_URL
	                //url: "/identityiq/plugin/identityandaccountdashboard/getIdentityData"
//	                url: "/identityiq/plugin/helloworld/getIdentityData"

	            })
	            .done(function (records) {
	          
/*
	            	  title=data.dataSetTitle;
	    			  dataSet=data.dataSet;

	    		    
				      $scope.identityData=[{"key":title, "values":dataSet}];
*/

    


//d3.csv('ndx.csv', function (data) {
//d3.json("agg5.json", function(error, records) {
 //       if (error) {alert(error);}
    // Since its a csv file we need to format the data a bit.
    var dateFormat = d3.time.format('%m/%d/%Y');
    var numberFormat = d3.format('.2f');

/*
    data.forEach(function (d) {
        d.dd = dateFormat.parse(d.date);
        d.month = d3.time.month(d.dd); // pre-calculate month for better performance
        d.close = +d.close; // coerce to number
        d.open = +d.open;
    });
*/
 // console.log(records);
  var dataSet=records["dataSet"];    
 // console.log(dataSet);
  var data=dataSet["values"];
 // console.log(data);
  var applications=dataSet["applications"];	
   
   var totalAccts=0;
   var totalIdents=0;
   
    data=data.sort(function(obj1, obj2) {
	    return obj1.date - obj2.date;
    });

    console.log(data);

    data.forEach(function (d) {
	    //console.log(d.date);
	    //console.log(new Date(d.date));
        d.dd = new Date(d.date);
        //d.date = parseDate(d.date);
        //console.log(d.dd);
        d.month = d3.time.month(d.dd); // pre-calculate month for better performance
                //console.log("month: "+d.month);
        d.week = d3.time.week(d.dd); // pre calc week
               //console.log("week: "+d.week);
          d.day = d3.time.day(d.dd); // pre calc day
                //  console.log("day: "+d.day);
        if (d.type=="identity")
             totalIdents=totalIdents+1;
           else
              totalAccts=totalAccts+1;
         d.totalIdents=totalIdents;


         d.totalAccts=totalAccts;
                    
    });
    
    

    //console.log(data);
  
    //### Create Crossfilter Dimensions and Groups

    //See the [crossfilter API](https://github.com/square/crossfilter/wiki/API-Reference) for reference.
    var ndx = crossfilter(data);
    var all = ndx.groupAll();

    // Dimension by year
    var yearlyDimension = ndx.dimension(function (d) {
        return d3.time.year(d.dd).getFullYear();
    });
    
    
       
    
    // Maintain running tallies by year as filters are applied or removed
    var yearlyPerformanceGroup = yearlyDimension.group().reduce(
        /* callback for when data is added to the current filter results */
        function (p, v) {
            ++p.count;
            p.absGain += v.close - v.open;
            p.fluctuation += Math.abs(v.close - v.open);
            p.sumIndex += (v.open + v.close) / 2;
            p.avgIndex = p.sumIndex / p.count;
            p.percentageGain = p.avgIndex ? (p.absGain / p.avgIndex) * 100 : 0;
            p.fluctuationPercentage = p.avgIndex ? (p.fluctuation / p.avgIndex) * 100 : 0;
            return p;
        },
        /* callback for when data is removed from the current filter results */
        function (p, v) {
            --p.count;
            p.absGain -= v.close - v.open;
            p.fluctuation -= Math.abs(v.close - v.open);
            p.sumIndex -= (v.open + v.close) / 2;
            p.avgIndex = p.count ? p.sumIndex / p.count : 0;
            p.percentageGain = p.avgIndex ? (p.absGain / p.avgIndex) * 100 : 0;
            p.fluctuationPercentage = p.avgIndex ? (p.fluctuation / p.avgIndex) * 100 : 0;
            return p;
        },
        /* initialize p */
        function () {
            return {
                count: 0,
                absGain: 0,
                fluctuation: 0,
                fluctuationPercentage: 0,
                sumIndex: 0,
                avgIndex: 0,
                percentageGain: 0
            };
        }
    );

    




    
    
    // Dimension by full date
    var overallDimension = ndx.dimension(function (d) {
        return d.dd;
    });


   
    
    var overallGroup = overallDimension.group();


 
      




    // Dimension by full date
    var dateDimension = ndx.dimension(function (d) {
        return d.day;
    });
    
    
     //dimension for running total of identities

      var identityDimension= ndx.dimension(function(d) {return [+d.totalIdents, +d.totalAccts]; });
      
      var sumAccts= identityDimension.group().reduceSum(function(d) { return d.totalAccts; });
      var tIdents = identityDimension.group().reduceSum(function(d) {return d.totalIdents;});
    

   var earliestDataDate = (dateDimension.bottom(1))[0].dd;
    //console.log((dateDimension.top(1))[0].dd);
    
    var potentialDate = earliestDataDate;
   // console.log("before loop");
  
    
    all_dates=[];
    while (potentialDate<=new Date())
    {
	    all_dates.push(d3.time.day(potentialDate));
	    
	    potentialDate=potentialDate.addDays(1);
    }
   // console.log("all days!");
   // console.log(all_dates);
/*
    
    var appGroups=[];
    var filteredAppGroup=[];
    applications.forEach(function(app) {
        appGroup.push({app,dateDimension.group().reduceSum(function(d){return d.type==app?1:0;}))});
        filteredAppGroup.push = ensure_group_bins(a)

    });
*/

    var ADDateGroup = dateDimension.group().reduceSum(function(d){return d.type=="Active Directory"?1:0;});
    var filteredADDateGroup = ensure_group_bins(ADDateGroup, all_dates);


    var IdentDateGroup = dateDimension.group().reduceSum(function(d){return d.type=="identity"?1:0;});
    var filteredIdentDateGroup = ensure_group_bins(IdentDateGroup, all_dates);   
    
    var dateGroup = dateDimension.group();
    
    //var dateGroup = dateDimension.group().reduceSum(function(d){return d.type=="identity"?1:0;});
    var filteredDateGroup = ensure_group_bins(dateGroup, all_dates);
        
  // Dimension by week
    var weekDimension = ndx.dimension(function (d) {
        return d.week;
    });   

    var weekGroup = weekDimension.group();
    
    
    // Dimension by month
    var moveMonths = ndx.dimension(function (d) {
        return d.month;
    });    
    
    
    // Group by total movement within month
    var monthlyMoveGroup = moveMonths.group().reduceSum(function (d) {
        return Math.abs(d.close - d.open);
    });
    
    var applicationDimension = ndx.dimension(function(d) { 
	    return d.type;
	});
    
    var applicationGroup = applicationDimension.group();
    
    // Group by total volume within move, and scale down result
    var volumeByMonthGroup = moveMonths.group().reduceSum(function (d) {
        return d.count;
    });
    var monthGroup = moveMonths.group();
    var indexAvgByMonthGroup = moveMonths.group().reduce(
        function (p, v) {
            ++p.days;
            p.total += (v.open + v.close) / 2;
            p.avg = Math.round(p.total / p.days);
            return p;
        },
        function (p, v) {
            --p.days;
            p.total -= (v.open + v.close) / 2;
            p.avg = p.days ? Math.round(p.total / p.days) : 0;
            return p;
        },
        function () {
            return {days: 0, total: 0, avg: 0};
        }
    );

    // Create categorical dimension
    var gainOrLoss = ndx.dimension(function (d) {
        return d.open > d.close ? 'Loss' : 'Gain';
    });
    // Produce counts records in the dimension
    var gainOrLossGroup = gainOrLoss.group();

    // Determine a histogram of percent changes
    var fluctuation = ndx.dimension(function (d) {
        return Math.round((d.close - d.open) / d.open * 100);
    });
    var fluctuationGroup = fluctuation.group();

    // Summarize volume by quarter
    var quarter = ndx.dimension(function (d) {
        var month = d.dd.getMonth();
        if (month <= 2) {
            return 'Q1';
        } else if (month > 2 && month <= 5) {
            return 'Q2';
        } else if (month > 5 && month <= 8) {
            return 'Q3';
        } else {
            return 'Q4';
        }
    });
   var quarterGroup = quarter.group();
/*

    var quarterGroup = quarter.group().reduceSum(function (d) {
        return d.volume;
    });
*/


  //console.log(dateGroup.all());
 // console.log("###############################");
 //console.log("***********groups********************");
  //console.log(dateGroup.all());
  //console.log(filteredDateGroup.all());
  
  
    // Counts per weekday
    var dayOfWeek = ndx.dimension(function (d) {
        var day = d.dd.getDay();
        var name = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        return day + '.' + name[day];
    });
    var dayOfWeekGroup = dayOfWeek.group();

    //### Define Chart Attributes
    // Define chart attributes using fluent methods. See the
    // [dc.js API Reference](https://github.com/dc-js/dc.js/blob/master/web/docs/api-latest.md) for more information
    //

    //#### Bubble Chart

    //Create a bubble chart and use the given css selector as anchor. You can also specify
    //an optional chart group for this chart to be scoped within. When a chart belongs
    //to a specific group then any interaction with the chart will only trigger redraws
    //on charts within the same chart group.
    // <br>API: [Bubble Chart](https://github.com/dc-js/dc.js/blob/master/web/docs/api-latest.md#bubble-chart)
    
    // this is changed into a scatter plot

    console.log(identityDimension);
    console.log(sumAccts);
    scatterPlot /* dc.bubbleChart('#yearly-bubble-chart', 'chartGroup') */
        // (_optional_) define chart width, `default = 200`
        .width(970)
        // (_optional_) define chart height, `default = 200`
        .height(250)
        // (_optional_) define chart transition duration, `default = 750`
        .transitionDuration(1500)
        .margins({top: 10, right: 60, bottom: 50, left: 40})
        .dimension(identityDimension)	
        //The bubble chart expects the groups are reduced to multiple values which are used
        //to generate x, y, and radius for each key (bubble) in the group
        .group(sumAccts)
        .symbolSize(1.5)


/*
        // (_optional_) define color function or array for bubbles: [ColorBrewer](http://colorbrewer2.org/)
        .colors(colorbrewer.RdYlGn[9])
        //(optional) define color domain to match your data domain if you want to bind data or color
        .colorDomain([-500, 500])
*/
    //##### Accessors


/*
        //Accessor functions are applied to each value returned by the grouping

        // `.colorAccessor` - the returned value will be passed to the `.colors()` scale to determine a fill color
        .colorAccessor(function (d) {
            return d.value.absGain;
        })
        // `.keyAccessor` - the `X` value will be passed to the `.x()` scale to determine pixel location
        .keyAccessor(function (p) {
            return p.key;
        })
        // `.valueAccessor` - the `Y` value will be passed to the `.y()` scale to determine pixel location
        .valueAccessor(function (p) {
            return p.value;
        })
*/
        // `.radiusValueAccessor` - the value will be passed to the `.r()` scale to determine radius size;
        //   by default this maps linearly to [0,100]
  //      .radiusValueAccessor(function (p) {

   //         return p.value.fluctuationPercentage;
    //    })
     //   .maxBubbleRelativeSize(0.3)
      // .x(d3.scale.linear().domain([d3.min(tIdents), d3.max(tIdents)]))
        .x(d3.time.scale().domain([earliestDataDate, new Date()]))
      //  .y(d3.scale.linear().domain([d3.min(sumAccts), d3.max(sumAccts)]))
      //  .r(d3.scale.linear().domain([0, 4000]))
        //##### Elastic Scaling

        //`.elasticY` and `.elasticX` determine whether the chart should rescale each axis to fit the data.
        .elasticY(true)
        .elasticX(true)
        //`.yAxisPadding` and `.xAxisPadding` add padding to data above and below their max values in the same unit
        //domains as the Accessors.
        .yAxisPadding(0)
        .xAxisPadding(0)
        // (_optional_) render horizontal grid lines, `default=false`
        .renderHorizontalGridLines(true)
        // (_optional_) render vertical grid lines, `default=false`
        .renderVerticalGridLines(true)
        // (_optional_) render an axis label below the x axis
        .xAxisLabel('Number of Identities')
        // (_optional_) render a vertical axis lable left of the y axis
        .yAxisLabel('Number of Accounts')
        //##### Labels and  Titles

        //Labels are displayed on the chart for each bubble. Titles displayed on mouseover.
        // (_optional_) whether chart should render labels, `default = true`
//         .renderLabel(true)
/*
        .label(function (p) {
            return p.key;
        })
*/
        // (_optional_) whether chart should render titles, `default = false`

        .renderTitle(true)
        .title(function (p) {
            return [
	            'Date: '+p.date,
	            'Number of Accounts: '+p.x,
	            'Number of Identities: '+p.y
      
            ].join('\n');
        });

        //#### Customize Axes

        // Set a custom tick format. Both `.yAxis()` and `.xAxis()` return an axis object,
        // so any additional method chaining applies to the axis, not the chart.
/*
        .yAxis().tickFormat(function (v) {
            return v + '%';
        }
*/

    // #### Pie/Donut Charts

    // Create a pie chart and use the given css selector as anchor. You can also specify
    // an optional chart group for this chart to be scoped within. When a chart belongs
    // to a specific group then any interaction with such chart will only trigger redraw
    // on other charts within the same chart group.
    // <br>API: [Pie Chart](https://github.com/dc-js/dc.js/blob/master/web/docs/api-latest.md#pie-chart)

    quarterChart /* dc.pieChart('#quarter-chart', 'chartGroup') */
        .width(450)
        
        .height(280)
        .radius(110)
        .innerRadius(65)
           .ordinalColors(['#41B467', '#43C06E', '#5acd81', '#6cd38f']) 
        .dimension(quarter)
        .title(function (d) { console.log(d);})
      
        .group(quarterGroup);

    //#### Row Chart

    // Create a row chart and use the given css selector as anchor. You can also specify
    // an optional chart group for this chart to be scoped within. When a chart belongs
    // to a specific group then any interaction with such chart will only trigger redraw
    // on other charts within the same chart group.
    // <br>API: [Row Chart](https://github.com/dc-js/dc.js/blob/master/web/docs/api-latest.md#row-chart)
    dayOfWeekChart /* dc.rowChart('#day-of-week-chart', 'chartGroup') */
        .width(500)
        .height(280)
        .margins({top: 20, left: 50, right: 75, bottom: 40})
        .group(dayOfWeekGroup)
        .dimension(dayOfWeek)
        // Assign colors to each value in the x scale domain
        .ordinalColors(['#1C1F25', '#1C1F25', '#1C1F25', '#1C1F25', '#1C1F25'])
        .label(function (d) {
            return d.key.split('.')[1];
        })
        // Title sets the row text
        .title(function (d) {
            return d.value;
        })
        .elasticX(true)
        .xAxis().ticks(4);



    // Create a row chart and use the given css selector as anchor. You can also specify
    // an optional chart group for this chart to be scoped within. When a chart belongs
    // to a specific group then any interaction with such chart will only trigger redraw
    // on other charts within the same chart group.
    // <br>API: [Row Chart](https://github.com/dc-js/dc.js/blob/master/web/docs/api-latest.md#row-chart)
    applicationChart /* dc.rowChart('#application-chart', 'chartGroup') */
        .width(970)
        .height(350)
        .margins({top: 50, left: 40, right: 50, bottom: 150})
        .group(applicationGroup)
        .dimension(applicationDimension)
        // Assign colors to each value in the x scale domain
        .ordinalColors(['#4C5566', '#444C5C', '#9ecae1', '#c6dbef', '#dadaeb'])
          .yAxisLabel('Number of Accounts')
        .x(d3.scale.ordinal().domain(applications))
        .xUnits(dc.units.ordinal)
        .gap(50)
/*
        .label(function (d) {
            return d.key;
        })
        // Title sets the row text
        .title(function (d) {
            return d.value;
        })
*/
        .elasticY(true)
                .renderlet(function (chart) {
                                    chart.selectAll("g.x text")
                                      .attr('dx', '-10')
                                      .attr('dy', '-5')
                                      .attr('transform', "rotate(-90)")
                                      .style('text-anchor','end');
                                })
        
        .yAxis().ticks(4);

    //#### Bar Chart
/*

    // Create a bar chart and use the given css selector as anchor. You can also specify
    // an optional chart group for this chart to be scoped within. When a chart belongs
    // to a specific group then any interaction with such chart will only trigger redraw
    // on other charts within the same chart group.
    // <br>API: [Bar Chart](https://github.com/dc-js/dc.js/blob/master/web/docs/api-latest.md#bar-chart)
    fluctuationChart /* dc.barChart('#volume-month-chart', 'chartGroup') 
        .width(420)
        .height(180)
        .margins({top: 10, right: 50, bottom: 30, left: 40})
        .dimension(fluctuation)
        .group(fluctuationGroup)
        .elasticY(true)
        // (_optional_) whether bar should be center to its x value. Not needed for ordinal chart, `default=false`
        .centerBar(true)
        // (_optional_) set gap between bars manually in px, `default=2`
        .gap(1)
        // (_optional_) set filter brush rounding
        .round(dc.round.floor)
        .alwaysUseRounding(true)
        .x(d3.scale.linear().domain([-25, 25]))
        .renderHorizontalGridLines(true)
        // Customize the filter displayed in the control span
        .filterPrinter(function (filters) {
            var filter = filters[0], s = '';
            s += numberFormat(filter[0]) + '% -> ' + numberFormat(filter[1]) + '%';
            return s;
        });

    // Customize axes
    fluctuationChart.xAxis().tickFormat(
        function (v) { return v + '%'; });
    fluctuationChart.yAxis().ticks(5);
*/

    //#### Stacked Area Chart

    //Specify an area chart by using a line chart with `.renderArea(true)`.
    // <br>API: [Stack Mixin](https://github.com/dc-js/dc.js/blob/master/web/docs/api-latest.md#stack-mixin),
    // [Line Chart](https://github.com/dc-js/dc.js/blob/master/web/docs/api-latest.md#line-chart)
    eventChart /* dc.lineChart('#monthly-move-chart', 'chartGroup') */
        .renderArea(true)
        .width(970)
        .height(200)
        .transitionDuration(1000)
        .margins({top: 30, right: 50, bottom: 20, left: 40})
        .dimension(dateDimension)
        .mouseZoomable(true)
//        .interpolate(basis) actually put this into the dc.js linechart call
    // Specify a "range chart" to link its brush extent with the zoom of the current "focus chart".
        .rangeChart(rangeChart)
   .x(d3.time.scale().domain([earliestDataDate, new Date()]))
        //.round(d3.time.day.round)
        //.xUnits(d3.time.day	)
        .elasticY(true)
        .renderHorizontalGridLines(true)
        .yAxisLabel('Number of Accounts')
    //##### Legend

        // Position the legend relative to the chart origin and specify items' height and separation.
///    .legend(dc.legend().x(800).y(10).itemHeight(13).gap(5))
        .brushOn(true)
        // Add the base layer of the stack with group. The second parameter specifies a series name for use in the
        // legend.
        // The `.valueAccessor` will be used for the base layer
        .group(filteredDateGroup)
//        .group(filteredIdentDateGroup)
        .valueAccessor(function (d) {
            return d.value;
        })
              // Stack additional layers with `.stack`. The first paramenter is a new group.
        // The second parameter is the series name. The third is a value accessor.
       // .stack(filteredADDateGroup, 'AD', function (d) {
        //    return d.value;
        //})

        .ordering(function(d){ return -d.value })
     
        
      

    //#### Range Chart

    // Since this bar chart is specified as "range chart" for the area chart, its brush extent
    // will always match the zoom of the area chart.
    rangeChart
        .width(970) /* dc.barChart('#monthly-volume-chart', 'chartGroup'); */
        .height(60)
        .margins({top: 10, right: 50, bottom: 20, left: 53})
        .dimension(dateDimension)
        .group(filteredDateGroup)
        .centerBar(true)
        .gap(1)
        .x(d3.time.scale().domain([new Date(2015,1,1), new Date()]))
//          .x(d3.time.scale().domain([earliestDataDate, new Date()]))
          .yAxis().ticks(3)
//        .round(d3.time.week.round)
 //       .alwaysUseRounding(true)
  //      .xUnits(d3.time.weeks);
        

    //#### Data Count

    // Create a data count widget and use the given css selector as anchor. You can also specify
    // an optional chart group for this chart to be scoped within. When a chart belongs
    // to a specific group then any interaction with such chart will only trigger redraw
    // on other charts within the same chart group.
    // <br>API: [Data Count Widget](https://github.com/dc-js/dc.js/blob/master/web/docs/api-latest.md#data-count-widget)
    //
    //```html
    //<div class='dc-data-count'>
    //  <span class='filter-count'></span>
    //  selected out of <span class='total-count'></span> records.
    //</div>
    //```

    filteredCount /* dc.dataCount('.dc-data-count', 'chartGroup'); */
        .dimension(ndx)
        .group(all)
        // (_optional_) `.html` sets different html when some records or all records are selected.
        // `.html` replaces everything in the anchor with the html given using the following function.
        // `%filter-count` and `%total-count` are replaced with the values obtained.
        .html({
            some: '<strong>%filter-count</strong> selected out of <strong>%total-count</strong> records' +
                ' | <a href=\'javascript:dc.filterAll(); dc.renderAll();\'>Reset All</a>',
            all: 'All records selected. Please click on the graph(s) to apply filters.'
        });

    //#### Data Table

    // Create a data table widget and use the given css selector as anchor. You can also specify
    // an optional chart group for this chart to be scoped within. When a chart belongs
    // to a specific group then any interaction with such chart will only trigger redraw
    // on other charts within the same chart group.
    // <br>API: [Data Table Widget](https://github.com/dc-js/dc.js/blob/master/web/docs/api-latest.md#data-table-widget)
    //
    // You can statically define the headers like in
    //
    // ```html
    //    <!-- anchor div for data table -->
    //    <div id='data-table'>
    //       <!-- create a custom header -->
    //       <div class='header'>
    //           <span>Date</span>
    //           <span>Open</span>
    //           <span>Close</span>
    //           <span>Change</span>
    //           <span>Volume</span>
    //       </div>
    //       <!-- data rows will filled in here -->
    //    </div>
    // ```
    // or do it programmatically using `.columns()`.

    eventTable /* dc.dataTable('.dc-data-table', 'chartGroup') */
        .width(970)
        .dimension(dateDimension)
        // Data table does not use crossfilter group but rather a closure
        // as a grouping function
        //.group(filteredDateGroup)
        .group(function (d) {
	        
	            
            var format = d3.format('02d');
            return d.dd.getFullYear() + '/' + format((d.dd.getMonth() + 1)) + '/' + format((d.dd.getDate()));
        })
        // (_optional_) max number of records to be shown, `default = 25`
        .size(50)
        // There are several ways to specify the columns; see the data-table documentation.
        // This code demonstrates generating the column header automatically based on the columns.
        .columns([
            // Use the `d.date` field; capitalized automatically
            {
	             label: 'Date',
	              format: function (d) {
		                 var format = d3.format('02d');
                    return d.dd.getFullYear() + '/' + format((d.dd.getMonth() + 1)) + '/' + format((d.dd.getDate()));
                    }
                },
            // Use `d.open`, `d.close`
            {
	            label: 'Identity / Application',
	            format: function (d) {
		            return d.type;
	            }
            },
            
            {
	            label: 'Name',
	            format: function(d) {
		            return '<a href=/identityiq/define/identity/identity.jsf?id='+d.id+'>'+d.displayName+'</>';  
	              }
	            }
	            
   
            // Use `d.volume`
        ])

        // (_optional_) sort using the given field, `default = function(d){return d;}`
        //.sortBy(function (d) {
	     //   return d.dd;
//            var format = d3.format('02d');
 //           return d.dd.getFullYear() + '/' + format((d.dd.getMonth() + 1)) + '/' + format((d.dd.getDay() + 1));
        //})
        // (_optional_) sort order, `default = d3.ascending`
        .order(d3.descending)
        // (_optional_) custom renderlet to post-process chart using [D3](http://d3js.org)
        .on('renderlet', function (table) {
            table.selectAll('.dc-table-group').classed('info', true);
        });

    /*
    //#### Geo Choropleth Chart

    //Create a choropleth chart and use the given css selector as anchor. You can also specify
    //an optional chart group for this chart to be scoped within. When a chart belongs
    //to a specific group then any interaction with such chart will only trigger redraw
    //on other charts within the same chart group.
    // <br>API: [Geo Chroropleth Chart][choro]
    // [choro]: https://github.com/dc-js/dc.js/blob/master/web/docs/api-latest.md#geo-choropleth-chart
    dc.geoChoroplethChart('#us-chart')
         // (_optional_) define chart width, default 200
        .width(990)
        // (optional) define chart height, default 200
        .height(500)
        // (optional) define chart transition duration, default 1000
        .transitionDuration(1000)
        // set crossfilter dimension, dimension key should match the name retrieved in geojson layer
        .dimension(states)
        // set crossfilter group
        .group(stateRaisedSum)
        // (_optional_) define color function or array for bubbles
        .colors(['#ccc', '#E2F2FF','#C4E4FF','#9ED2FF','#81C5FF','#6BBAFF','#51AEFF','#36A2FF','#1E96FF','#0089FF',
            '#0061B5'])
        // (_optional_) define color domain to match your data domain if you want to bind data or color
        .colorDomain([-5, 200])
        // (_optional_) define color value accessor
        .colorAccessor(function(d, i){return d.value;})
        // Project the given geojson. You can call this function multiple times with different geojson feed to generate
        // multiple layers of geo paths.
        //
        // * 1st param - geojson data
        // * 2nd param - name of the layer which will be used to generate css class
        // * 3rd param - (_optional_) a function used to generate key for geo path, it should match the dimension key
        // in order for the coloring to work properly
        .overlayGeoJson(statesJson.features, 'state', function(d) {
            return d.properties.name;
        })
        // (_optional_) closure to generate title for path, `default = d.key + ': ' + d.value`
        .title(function(d) {
            return 'State: ' + d.key + '\nTotal Amount Raised: ' + numberFormat(d.value ? d.value : 0) + 'M';
        });

        //#### Bubble Overlay Chart

        // Create a overlay bubble chart and use the given css selector as anchor. You can also specify
        // an optional chart group for this chart to be scoped within. When a chart belongs
        // to a specific group then any interaction with the chart will only trigger redraw
        // on charts within the same chart group.
        // <br>API: [Bubble Overlay Chart][bubble]
        // [bubble]: https://github.com/dc-js/dc.js/blob/master/web/docs/api-latest.md#bubble-overlay-chart
        dc.bubbleOverlay('#bubble-overlay', 'chartGroup')
            // The bubble overlay chart does not generate its own svg element but rather reuses an existing
            // svg to generate its overlay layer
            .svg(d3.select('#bubble-overlay svg'))
            // (_optional_) define chart width, `default = 200`
            .width(990)
            // (_optional_) define chart height, `default = 200`
            .height(500)
            // (_optional_) define chart transition duration, `default = 1000`
            .transitionDuration(1000)
            // Set crossfilter dimension, dimension key should match the name retrieved in geo json layer
            .dimension(states)
            // Set crossfilter group
            .group(stateRaisedSum)
            // Closure used to retrieve x value from multi-value group
            .keyAccessor(function(p) {return p.value.absGain;})
            // Closure used to retrieve y value from multi-value group
            .valueAccessor(function(p) {return p.value.percentageGain;})
            // (_optional_) define color function or array for bubbles
            .colors(['#ccc', '#E2F2FF','#C4E4FF','#9ED2FF','#81C5FF','#6BBAFF','#51AEFF','#36A2FF','#1E96FF','#0089FF',
                '#0061B5'])
            // (_optional_) define color domain to match your data domain if you want to bind data or color
            .colorDomain([-5, 200])
            // (_optional_) define color value accessor
            .colorAccessor(function(d, i){return d.value;})
            // Closure used to retrieve radius value from multi-value group
            .radiusValueAccessor(function(p) {return p.value.fluctuationPercentage;})
            // set radius scale
            .r(d3.scale.linear().domain([0, 3]))
            // (_optional_) whether chart should render labels, `default = true`
            .renderLabel(true)
            // (_optional_) closure to generate label per bubble, `default = group.key`
            .label(function(p) {return p.key.getFullYear();})
            // (_optional_) whether chart should render titles, `default = false`
            .renderTitle(true)
            // (_optional_) closure to generate title per bubble, `default = d.key + ': ' + d.value`
            .title(function(d) {
                return 'Title: ' + d.key;
            })
            // add data point to its layer dimension key that matches point name: it will be used to
            // generate a bubble. Multiple data points can be added to the bubble overlay to generate
            // multiple bubbles.
            .point('California', 100, 120)
            .point('Colorado', 300, 120)
            // (_optional_) setting debug flag to true will generate a transparent layer on top of
            // bubble overlay which can be used to obtain relative `x`,`y` coordinate for specific
            // data point, `default = false`
            .debug(true);
    */

    //#### Rendering

    //simply call `.renderAll()` to render all charts on the page
    dc.renderAll();
    /*
    // Or you can render charts belonging to a specific chart group
    dc.renderAll('group');
    // Once rendered you can call `.redrawAll()` to update charts incrementally when the data
    // changes, without re-rendering everything
    dc.redrawAll();
    // Or you can choose to redraw only those charts associated with a specific chart group
    dc.redrawAll('group');
    */

});

//#### Versions

//Determine the current version of dc with `dc.version`
d3.selectAll('#version').text(dc.version);

// Determine latest stable version in the repo via Github API
d3.json('https://api.github.com/repos/dc-js/dc.js/releases/latest', function (error, latestRelease) {
    /*jshint camelcase: false */
    d3.selectAll('#latest').text(latestRelease.tag_name); /* jscs:disable */
});
